import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Sidebar = ({ isCollapsed = false, onToggleCollapse }) => {
  const location = useLocation();
  const [conversationPanelOpen, setConversationPanelOpen] = useState(false);

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/dashboard',
      icon: 'LayoutDashboard',
      description: 'Workspace management and overview'
    },
    {
      label: 'Generate Workspace',
      path: '/workspace-generator',
      icon: 'Wand2',
      description: 'AI-powered workspace creation'
    },
    {
      label: 'Preview & Deploy',
      path: '/workspace-preview',
      icon: 'Eye',
      description: 'Review and deploy workspaces'
    }
  ];

  const quickActions = [
    { label: 'Templates', icon: 'Layout', count: 12 },
    { label: 'Recent Workspaces', icon: 'Clock', count: 5 },
    { label: 'Favorites', icon: 'Star', count: 3 }
  ];

  const isActivePath = (path) => location?.pathname === path;

  const handleNavigation = (path) => {
    window.location.href = path;
  };

  const toggleConversationPanel = () => {
    setConversationPanelOpen(!conversationPanelOpen);
  };

  return (
    <>
      {/* Main Sidebar */}
      <aside className={`
        fixed left-0 top-16 bottom-0 z-40 bg-surface border-r border-border
        transition-all duration-300 ease-spring
        ${isCollapsed ? 'w-16' : 'w-64'}
      `}>
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between">
              {!isCollapsed && (
                <div className="flex items-center space-x-2">
                  <Icon name="Sparkles" size={20} className="text-primary" />
                  <span className="font-medium text-foreground">Workspace Hub</span>
                </div>
              )}
              <button
                onClick={onToggleCollapse}
                className="p-1.5 rounded-md hover:bg-muted transition-colors"
                title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              >
                <Icon name={isCollapsed ? 'ChevronRight' : 'ChevronLeft'} size={16} />
              </button>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            {navigationItems?.map((item) => (
              <button
                key={item?.path}
                onClick={() => handleNavigation(item?.path)}
                className={`
                  w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium
                  transition-all duration-200 ease-spring hover:bg-muted group
                  ${isActivePath(item?.path) 
                    ? 'bg-primary/10 text-primary border border-primary/20' :'text-muted-foreground hover:text-foreground'
                  }
                `}
                title={isCollapsed ? item?.label : item?.description}
              >
                <Icon name={item?.icon} size={18} />
                {!isCollapsed && (
                  <>
                    <span className="flex-1 text-left">{item?.label}</span>
                    {isActivePath(item?.path) && (
                      <div className="w-2 h-2 bg-primary rounded-full" />
                    )}
                  </>
                )}
              </button>
            ))}
          </nav>

          {/* Quick Access Section */}
          {!isCollapsed && (
            <div className="p-4 border-t border-border">
              <div className="mb-3">
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Quick Access
                </h3>
              </div>
              <div className="space-y-1">
                {quickActions?.map((action) => (
                  <button
                    key={action?.label}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-md text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center space-x-2">
                      <Icon name={action?.icon} size={16} />
                      <span>{action?.label}</span>
                    </div>
                    <span className="text-xs bg-muted px-1.5 py-0.5 rounded">
                      {action?.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* AI Conversation Toggle */}
          <div className="p-4 border-t border-border">
            <Button
              variant="outline"
              size="sm"
              iconName="MessageSquare"
              iconPosition="left"
              onClick={toggleConversationPanel}
              className={`w-full ${isCollapsed ? 'px-2' : ''}`}
              title="AI Conversation History"
            >
              {!isCollapsed && 'AI Chat'}
            </Button>
          </div>
        </div>
      </aside>
      {/* Conversation Context Panel */}
      {conversationPanelOpen && (
        <div className="fixed inset-0 z-50 lg:inset-auto lg:right-0 lg:top-16 lg:bottom-0 lg:w-80">
          {/* Mobile Backdrop */}
          <div 
            className="lg:hidden fixed inset-0 bg-black/50"
            onClick={() => setConversationPanelOpen(false)}
          />
          
          {/* Panel Content */}
          <div className="relative bg-surface border-l border-border h-full flex flex-col shadow-floating lg:shadow-none">
            {/* Panel Header */}
            <div className="p-4 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Icon name="Bot" size={20} className="text-primary" />
                  <span className="font-medium text-foreground">AI Assistant</span>
                </div>
                <button
                  onClick={() => setConversationPanelOpen(false)}
                  className="p-1.5 rounded-md hover:bg-muted transition-colors"
                >
                  <Icon name="X" size={16} />
                </button>
              </div>
            </div>

            {/* Conversation History */}
            <div className="flex-1 p-4 overflow-y-auto">
              <div className="space-y-4">
                {/* Sample conversation items */}
                <div className="flex space-x-3">
                  <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon name="User" size={14} />
                  </div>
                  <div className="flex-1">
                    <div className="bg-muted rounded-lg p-3 text-sm">
                      Create a modern dashboard for project management
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">2 minutes ago</div>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon name="Bot" size={14} color="white" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-primary/10 border border-primary/20 rounded-lg p-3 text-sm">
                      I'll help you create a modern project management dashboard. Let me generate a workspace with task boards, analytics, and team collaboration features.
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">2 minutes ago</div>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon name="User" size={14} />
                  </div>
                  <div className="flex-1">
                    <div className="bg-muted rounded-lg p-3 text-sm">
                      Add dark mode support and mobile responsiveness
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">1 minute ago</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Prompts */}
            <div className="p-4 border-t border-border">
              <div className="mb-3">
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Quick Prompts
                </span>
              </div>
              <div className="space-y-2">
                <button className="w-full text-left p-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors">
                  "Create an e-commerce dashboard"
                </button>
                <button className="w-full text-left p-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors">
                  "Add user authentication"
                </button>
                <button className="w-full text-left p-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors">
                  "Generate API documentation"
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Sidebar;