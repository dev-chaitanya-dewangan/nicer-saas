import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const location = useLocation();
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/dashboard',
      icon: 'LayoutDashboard',
      description: 'Workspace management hub'
    },
    {
      label: 'Generate',
      path: '/workspace-generator',
      icon: 'Wand2',
      description: 'AI workspace creation'
    },
    {
      label: 'Preview',
      path: '/workspace-preview',
      icon: 'Eye',
      description: 'Review and deploy'
    }
  ];

  const isActivePath = (path) => location?.pathname === path;

  const handleNavigation = (path) => {
    window.location.href = path;
  };

  const toggleProfile = () => {
    setIsProfileOpen(!isProfileOpen);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-surface border-b border-border h-16">
      <div className="flex items-center justify-between h-full px-6">
        {/* Logo Section */}
        <div className="flex items-center">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="Zap" size={20} color="white" strokeWidth={2.5} />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-semibold text-foreground">Nicer SaaS</span>
              <span className="text-xs text-muted-foreground -mt-1">AI Workspace Generator</span>
            </div>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="hidden md:flex items-center space-x-1">
          {navigationItems?.map((item) => (
            <button
              key={item?.path}
              onClick={() => handleNavigation(item?.path)}
              className={`
                flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium
                transition-all duration-200 ease-spring hover:bg-muted
                ${isActivePath(item?.path) 
                  ? 'bg-primary/10 text-primary border border-primary/20' :'text-muted-foreground hover:text-foreground'
                }
              `}
              title={item?.description}
            >
              <Icon name={item?.icon} size={16} />
              <span>{item?.label}</span>
            </button>
          ))}
        </nav>

        {/* Right Section */}
        <div className="flex items-center space-x-4">
          {/* Quick Actions */}
          <div className="hidden lg:flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              iconName="Plus"
              iconPosition="left"
              onClick={() => handleNavigation('/workspace-generator')}
              className="text-sm"
            >
              New Workspace
            </Button>
          </div>

          {/* Profile Menu */}
          <div className="relative">
            <button
              onClick={toggleProfile}
              className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted transition-colors duration-200"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                <Icon name="User" size={16} color="white" />
              </div>
              <Icon name="ChevronDown" size={16} className="text-muted-foreground" />
            </button>

            {/* Profile Dropdown */}
            {isProfileOpen && (
              <div className="absolute right-0 top-full mt-2 w-56 bg-popover border border-border rounded-lg shadow-floating z-50">
                <div className="p-3 border-b border-border">
                  <div className="text-sm font-medium text-foreground">John Doe</div>
                  <div className="text-xs text-muted-foreground">john@company.com</div>
                  <div className="text-xs text-accent font-medium mt-1">Pro Plan</div>
                </div>
                <div className="py-2">
                  <button className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-foreground hover:bg-muted transition-colors">
                    <Icon name="Settings" size={16} />
                    <span>Settings</span>
                  </button>
                  <button className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-foreground hover:bg-muted transition-colors">
                    <Icon name="HelpCircle" size={16} />
                    <span>Help & Support</span>
                  </button>
                  <button className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-foreground hover:bg-muted transition-colors">
                    <Icon name="CreditCard" size={16} />
                    <span>Billing</span>
                  </button>
                  <div className="border-t border-border mt-2 pt-2">
                    <button className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors">
                      <Icon name="LogOut" size={16} />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden p-2 rounded-md hover:bg-muted transition-colors">
            <Icon name="Menu" size={20} />
          </button>
        </div>
      </div>
      {/* Workflow Progress Indicator */}
      <div className="hidden md:block absolute bottom-0 left-0 right-0 h-1 bg-muted">
        <div className="h-full bg-gradient-to-r from-primary via-accent to-success transition-all duration-300 ease-spring"
             style={{ 
               width: location?.pathname === '/dashboard' ? '33%' : 
                      location?.pathname === '/workspace-generator' ? '66%' : 
                      location?.pathname === '/workspace-preview' ? '100%' : '0%' 
             }}
        />
      </div>
      {/* Click outside handler for profile dropdown */}
      {isProfileOpen && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setIsProfileOpen(false)}
        />
      )}
    </header>
  );
};

export default Header;