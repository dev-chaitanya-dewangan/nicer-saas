import React, { useState, useEffect } from 'react';
import { ChevronDown, Zap, Brain, Sparkles, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import aiService from '../../services/aiService';
import Icon from '../AppIcon';


const AIProviderSelector = ({ onProviderChange, disabled = false }) => {
  const [selectedProvider, setSelectedProvider] = useState('openRouter');
  const [selectedModel, setSelectedModel] = useState('');
  const [isProviderOpen, setIsProviderOpen] = useState(false);
  const [isModelOpen, setIsModelOpen] = useState(false);
  const [availableModels, setAvailableModels] = useState([]);

  const providers = [
    {
      id: 'openRouter',
      name: 'OpenRouter',
      icon: Zap,
      description: 'Free AI models',
      color: 'from-green-500 to-emerald-600',
      badge: 'FREE'
    },
    {
      id: 'gemini',
      name: 'Google Gemini',
      icon: Sparkles,
      description: 'Fast and capable',
      color: 'from-blue-500 to-cyan-600',
      badge: 'FREE'
    },
    {
      id: 'openai',
      name: 'OpenAI',
      icon: Brain,
      description: 'GPT models (paid)',
      color: 'from-purple-500 to-pink-600',
      badge: 'PAID'
    }
  ];

  useEffect(() => {
    aiService?.setProvider(selectedProvider);
    const models = aiService?.getAvailableModels();
    setAvailableModels(models);
    
    if (models?.length > 0 && !selectedModel) {
      setSelectedModel(models?.[0]);
      aiService?.setProvider(selectedProvider, models?.[0]);
    }
  }, [selectedProvider]);

  useEffect(() => {
    if (selectedModel) {
      aiService?.setProvider(selectedProvider, selectedModel);
      onProviderChange?.(selectedProvider, selectedModel);
    }
  }, [selectedProvider, selectedModel, onProviderChange]);

  const handleProviderSelect = (providerId) => {
    setSelectedProvider(providerId);
    setSelectedModel('');
    setIsProviderOpen(false);
  };

  const handleModelSelect = (model) => {
    setSelectedModel(model);
    setIsModelOpen(false);
  };

  const selectedProviderData = providers?.find(p => p?.id === selectedProvider);
  const SelectedProviderIcon = selectedProviderData?.icon;

  return (
    <div className="space-y-3">
      {/* Provider Selector */}
      <div className="relative">
        <label className="block text-sm font-medium text-foreground mb-2">
          AI Provider
        </label>
        <button
          type="button"
          disabled={disabled}
          onClick={() => setIsProviderOpen(!isProviderOpen)}
          className={`
            w-full bg-background border border-border rounded-lg px-4 py-3 
            flex items-center justify-between hover:bg-accent/50 transition-colors
            ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
          `}
        >
          <div className="flex items-center space-x-3">
            {SelectedProviderIcon && (
              <div className={`w-6 h-6 rounded bg-gradient-to-r ${selectedProviderData?.color} flex items-center justify-center`}>
                <SelectedProviderIcon className="w-4 h-4 text-white" />
              </div>
            )}
            <div className="text-left">
              <div className="flex items-center space-x-2">
                <span className="font-medium text-foreground">{selectedProviderData?.name}</span>
                <span className={`
                  px-2 py-0.5 text-xs font-medium rounded-full
                  ${selectedProviderData?.badge === 'FREE' ?'bg-green-100 text-green-800' :'bg-orange-100 text-orange-800'}
                `}>
                  {selectedProviderData?.badge}
                </span>
              </div>
              <p className="text-sm text-muted-foreground">{selectedProviderData?.description}</p>
            </div>
          </div>
          <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform ${isProviderOpen ? 'rotate-180' : ''}`} />
        </button>

        <AnimatePresence>
          {isProviderOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-full left-0 right-0 mt-1 bg-background border border-border rounded-lg shadow-lg z-50 py-1"
            >
              {providers?.map((provider) => {
                const Icon = provider?.icon;
                const isSelected = provider?.id === selectedProvider;
                
                return (
                  <button
                    key={provider?.id}
                    onClick={() => handleProviderSelect(provider?.id)}
                    className={`
                      w-full px-4 py-3 flex items-center space-x-3 hover:bg-accent/50 transition-colors text-left
                      ${isSelected ? 'bg-accent/30' : ''}
                    `}
                  >
                    <div className={`w-6 h-6 rounded bg-gradient-to-r ${provider?.color} flex items-center justify-center`}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium text-foreground">{provider?.name}</span>
                        <span className={`
                          px-2 py-0.5 text-xs font-medium rounded-full
                          ${provider?.badge === 'FREE' ?'bg-green-100 text-green-800' :'bg-orange-100 text-orange-800'}
                        `}>
                          {provider?.badge}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">{provider?.description}</p>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 text-primary" />
                    )}
                  </button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      {/* Model Selector */}
      {availableModels?.length > 0 && (
        <div className="relative">
          <label className="block text-sm font-medium text-foreground mb-2">
            Model
          </label>
          <button
            type="button"
            disabled={disabled}
            onClick={() => setIsModelOpen(!isModelOpen)}
            className={`
              w-full bg-background border border-border rounded-lg px-4 py-3 
              flex items-center justify-between hover:bg-accent/50 transition-colors
              ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
            `}
          >
            <div className="text-left">
              <span className="font-medium text-foreground">
                {selectedModel || 'Select a model'}
              </span>
              {selectedModel && selectedProvider === 'openRouter' && (
                <p className="text-sm text-green-600 font-medium">Free Model</p>
              )}
            </div>
            <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform ${isModelOpen ? 'rotate-180' : ''}`} />
          </button>

          <AnimatePresence>
            {isModelOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute top-full left-0 right-0 mt-1 bg-background border border-border rounded-lg shadow-lg z-50 py-1 max-h-64 overflow-y-auto"
              >
                {availableModels?.map((model) => {
                  const isSelected = model === selectedModel;
                  const isFree = selectedProvider === 'openRouter' || 
                                (selectedProvider === 'gemini' && model?.includes('flash'));
                  
                  return (
                    <button
                      key={model}
                      onClick={() => handleModelSelect(model)}
                      className={`
                        w-full px-4 py-3 flex items-center justify-between hover:bg-accent/50 transition-colors text-left
                        ${isSelected ? 'bg-accent/30' : ''}
                      `}
                    >
                      <div>
                        <span className="font-medium text-foreground">{model}</span>
                        {isFree && (
                          <span className="ml-2 px-2 py-0.5 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            FREE
                          </span>
                        )}
                      </div>
                      {isSelected && (
                        <Check className="w-4 h-4 text-primary" />
                      )}
                    </button>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};

export default AIProviderSelector;