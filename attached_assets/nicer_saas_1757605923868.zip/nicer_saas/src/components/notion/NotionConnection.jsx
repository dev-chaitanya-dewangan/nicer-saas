import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import notionService from '../../services/notionService';
import Button from '../ui/Button';

const NotionConnection = ({ onConnectionChange, showConnect = true }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionError, setConnectionError] = useState(null);
  const [workspaceInfo, setWorkspaceInfo] = useState(null);
  const [authUrl, setAuthUrl] = useState('');

  useEffect(() => {
    // Check if we have a stored access token
    const token = localStorage.getItem('notion_access_token');
    if (token) {
      initializeConnection(token);
    }

    // Generate auth URL
    setAuthUrl(notionService?.getAuthUrl());

    // Check for OAuth callback
    handleOAuthCallback();
  }, []);

  const handleOAuthCallback = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams?.get('code');
    const error = urlParams?.get('error');

    if (error) {
      setConnectionError(`OAuth error: ${error}`);
      return;
    }

    if (code) {
      setIsConnecting(true);
      try {
        const result = await notionService?.exchangeCodeForToken(code, window.location?.origin + '/auth/callback');
        
        // Store the access token
        localStorage.setItem('notion_access_token', result?.accessToken);
        localStorage.setItem('notion_workspace', JSON.stringify({
          id: result?.workspaceId,
          name: result?.workspaceName,
          icon: result?.workspaceIcon
        }));

        setWorkspaceInfo({
          name: result?.workspaceName,
          icon: result?.workspaceIcon,
          id: result?.workspaceId
        });

        setIsConnected(true);
        setConnectionError(null);
        onConnectionChange?.(true, result?.accessToken);

        // Clean up URL
        window.history?.replaceState({}, document.title, window.location?.pathname);
      } catch (error) {
        console.error('OAuth callback error:', error);
        setConnectionError(error?.message);
      } finally {
        setIsConnecting(false);
      }
    }
  };

  const initializeConnection = async (token) => {
    try {
      setIsConnecting(true);
      notionService?.initialize(token);
      
      // Try to get workspace info to verify connection
      const info = await notionService?.getWorkspaceInfo();
      const storedWorkspace = JSON.parse(localStorage.getItem('notion_workspace') || '{}');
      
      setWorkspaceInfo({
        name: storedWorkspace?.name || 'Notion Workspace',
        icon: storedWorkspace?.icon || '📝',
        id: storedWorkspace?.id
      });
      
      setIsConnected(true);
      setConnectionError(null);
      onConnectionChange?.(true, token);
    } catch (error) {
      console.error('Connection initialization error:', error);
      setConnectionError(error?.message);
      // Clear invalid token
      localStorage.removeItem('notion_access_token');
      localStorage.removeItem('notion_workspace');
    } finally {
      setIsConnecting(false);
    }
  };

  const handleConnect = () => {
    window.location.href = authUrl;
  };

  const handleDisconnect = () => {
    localStorage.removeItem('notion_access_token');
    localStorage.removeItem('notion_workspace');
    setIsConnected(false);
    setWorkspaceInfo(null);
    setConnectionError(null);
    onConnectionChange?.(false, null);
  };

  const handleReconnect = () => {
    setConnectionError(null);
    const token = localStorage.getItem('notion_access_token');
    if (token) {
      initializeConnection(token);
    } else {
      handleConnect();
    }
  };

  if (isConnecting) {
    return (
      <div className="bg-background border border-border rounded-lg p-6">
        <div className="flex items-center justify-center space-x-3">
          <RefreshCw className="w-5 h-5 animate-spin text-primary" />
          <span className="text-foreground">Connecting to Notion...</span>
        </div>
      </div>
    );
  }

  if (isConnected && workspaceInfo) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-background border border-border rounded-lg p-6"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground flex items-center space-x-2">
                <span>{workspaceInfo?.icon}</span>
                <span>{workspaceInfo?.name}</span>
              </h3>
              <p className="text-sm text-green-600 font-medium">Connected to Notion</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDisconnect}
            >
              Disconnect
            </Button>
          </div>
        </div>
      </motion.div>
    );
  }

  if (connectionError) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-background border border-red-200 rounded-lg p-6"
      >
        <div className="flex items-start space-x-3">
          <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="font-semibold text-foreground">Connection Error</h3>
            <p className="text-sm text-red-600 mt-1">{connectionError}</p>
            <div className="mt-4 flex space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={handleReconnect}
                iconName="RefreshCw"
                iconPosition="left"
              >
                Retry Connection
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  if (!showConnect) {
    return (
      <div className="bg-background border border-border rounded-lg p-6">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <h3 className="font-semibold text-foreground mb-2">Not Connected to Notion</h3>
          <p className="text-sm text-muted-foreground">
            Connect your Notion account to create workspaces
          </p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-background border border-border rounded-lg p-6"
    >
      <div className="text-center">
        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-2xl">📝</span>
        </div>
        <h3 className="text-xl font-bold text-foreground mb-2">Connect to Notion</h3>
        <p className="text-muted-foreground mb-6">
          Connect your Notion account to create beautiful, functional workspaces automatically
        </p>
        
        <div className="space-y-4">
          <Button
            onClick={handleConnect}
            iconName="ExternalLink"
            iconPosition="right"
            className="w-full"
          >
            Connect Notion Account
          </Button>
          
          <div className="text-xs text-muted-foreground">
            <p>🔒 Secure OAuth connection</p>
            <p>✨ No passwords stored</p>
            <p>🎯 Limited permissions requested</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default NotionConnection;