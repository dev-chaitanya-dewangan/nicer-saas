import { openai, openRouter, gemini, FREE_MODELS } from './aiClients';

/**
 * AI Service for handling multiple AI providers
 */
class AIService {
  constructor() {
    this.currentProvider = 'openRouter'; // Default to OpenRouter for free models
    this.currentModel = FREE_MODELS?.openRouter?.[0]; // Default free model
  }

  /**
   * Set the AI provider and model
   */
  setProvider(provider, model = null) {
    this.currentProvider = provider;
    
    if (model) {
      this.currentModel = model;
    } else {
      // Set default free model for the provider
      switch (provider) {
        case 'openRouter':
          this.currentModel = FREE_MODELS?.openRouter?.[0];
          break;
        case 'gemini':
          this.currentModel = FREE_MODELS?.gemini?.[0];
          break;
        case 'openai':
          this.currentModel = 'gpt-3.5-turbo'; // Cheapest OpenAI model
          break;
        default:
          this.currentModel = FREE_MODELS?.openRouter?.[0];
      }
    }
  }

  /**
   * Generate text using the current provider
   */
  async generateText(prompt, options = {}) {
    const {
      systemMessage = 'You are a helpful AI assistant specializing in creating beautiful, functional Notion workspaces.',
      temperature = 0.7,
      maxTokens = 2000,
      stream = false
    } = options;

    try {
      switch (this.currentProvider) {
        case 'openai':
          return await this._generateWithOpenAI(prompt, systemMessage, { temperature, maxTokens, stream });
        
        case 'openRouter':
          return await this._generateWithOpenRouter(prompt, systemMessage, { temperature, maxTokens, stream });
        
        case 'gemini':
          return await this._generateWithGemini(prompt, systemMessage, { temperature, maxTokens, stream });
        
        default:
          throw new Error(`Unsupported provider: ${this.currentProvider}`);
      }
    } catch (error) {
      console.error(`Error with ${this.currentProvider}:`, error);
      
      // Fallback to another provider if current fails
      if (this.currentProvider !== 'openRouter') {
        console.log('Falling back to OpenRouter...');
        this.setProvider('openRouter');
        return await this._generateWithOpenRouter(prompt, systemMessage, { temperature, maxTokens, stream });
      }
      
      throw error;
    }
  }

  /**
   * Generate structured workspace data
   */
  async generateWorkspaceStructure(prompt, requirements = {}) {
    const systemMessage = `You are an expert Notion workspace architect. Create a detailed workspace structure based on the user's requirements. 

Response must be valid JSON with this exact structure:
{
  "title": "Workspace Title",
  "description": "Brief description",
  "databases": [
    {
      "name": "Database Name",
      "icon": "📊",
      "properties": [
        {"name": "Property Name", "type": "title"},
        {"name": "Status", "type": "select", "options": ["Option1", "Option2"]},
        {"name": "Date", "type": "date"},
        {"name": "Notes", "type": "rich_text"}
      ]
    }
  ],
  "pages": [
    {
      "name": "Page Name",
      "icon": "📄",
      "content": "Page content description",
      "type": "page"
    }
  ],
  "templates": [
    {
      "name": "Template Name",
      "database": "Database Name",
      "properties": {"Status": "Option1"}
    }
  ],
  "views": [
    {
      "name": "View Name",
      "database": "Database Name",
      "type": "table",
      "filter": {"property": "Status", "condition": "equals", "value": "Option1"}
    }
  ]
}

Make it aesthetically beautiful and highly functional.`;

    const enhancedPrompt = `${prompt}\n\nRequirements: ${JSON.stringify(requirements)}`;
    
    try {
      const response = await this.generateText(enhancedPrompt, {
        systemMessage,
        temperature: 0.3, // Lower temperature for more consistent structure
        maxTokens: 3000
      });

      // Parse and validate JSON response
      const workspaceData = JSON.parse(response);
      return this._validateWorkspaceStructure(workspaceData);
    } catch (error) {
      console.error('Error generating workspace structure:', error);
      
      // Return fallback structure
      return this._getFallbackWorkspaceStructure(prompt);
    }
  }

  /**
   * Generate with OpenAI
   */
  async _generateWithOpenAI(prompt, systemMessage, options) {
    const response = await openai?.chat?.completions?.create({
      model: this.currentModel || 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: systemMessage },
        { role: 'user', content: prompt }
      ],
      temperature: options?.temperature,
      max_tokens: options?.maxTokens,
      stream: options?.stream
    });

    if (options?.stream) {
      return response; // Return stream for handling by caller
    }

    return response?.choices?.[0]?.message?.content;
  }

  /**
   * Generate with OpenRouter (free models)
   */
  async _generateWithOpenRouter(prompt, systemMessage, options) {
    const response = await openRouter?.chat?.completions?.create({
      model: this.currentModel,
      messages: [
        { role: 'system', content: systemMessage },
        { role: 'user', content: prompt }
      ],
      temperature: options?.temperature,
      max_tokens: options?.maxTokens,
      stream: options?.stream
    });

    if (options?.stream) {
      return response;
    }

    return response?.choices?.[0]?.message?.content;
  }

  /**
   * Generate with Gemini
   */
  async _generateWithGemini(prompt, systemMessage, options) {
    const model = gemini?.getGenerativeModel({ 
      model: this.currentModel || 'gemini-1.5-flash',
      generationConfig: {
        temperature: options?.temperature,
        maxOutputTokens: options?.maxTokens
      }
    });

    const fullPrompt = `${systemMessage}\n\nUser: ${prompt}`;
    
    if (options?.stream) {
      const result = await model?.generateContentStream(fullPrompt);
      return result?.stream;
    }

    const result = await model?.generateContent(fullPrompt);
    const response = await result?.response;
    return response?.text();
  }

  /**
   * Analyze image with AI
   */
  async analyzeImage(imageFile, prompt = "Analyze this image") {
    try {
      if (this.currentProvider === 'gemini') {
        return await this._analyzeImageWithGemini(imageFile, prompt);
      } else {
        // Use OpenAI/OpenRouter for image analysis
        return await this._analyzeImageWithOpenAI(imageFile, prompt);
      }
    } catch (error) {
      console.error('Image analysis error:', error);
      throw error;
    }
  }

  async _analyzeImageWithGemini(imageFile, prompt) {
    const model = gemini?.getGenerativeModel({ model: 'gemini-1.5-pro' });

    // Convert image to base64
    const toBase64 = (file) =>
      new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = reject;
      });

    const imageBase64 = await toBase64(imageFile);
    const imagePart = {
      inlineData: {
        data: imageBase64,
        mimeType: imageFile?.type,
      },
    };

    const result = await model?.generateContent([prompt, imagePart]);
    const response = await result?.response;
    return response?.text();
  }

  async _analyzeImageWithOpenAI(imageFile, prompt) {
    const imageUrl = URL.createObjectURL(imageFile);
    
    const response = await openai?.chat?.completions?.create({
      model: "gpt-4-vision-preview",
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: prompt },
            { type: "image_url", image_url: { url: imageUrl } }
          ],
        },
      ],
      max_tokens: 2000,
    });

    return response?.choices?.[0]?.message?.content;
  }

  /**
   * Validate workspace structure
   */
  _validateWorkspaceStructure(data) {
    const required = ['title', 'description', 'databases', 'pages'];
    const missing = required?.filter(key => !data?.[key]);
    
    if (missing?.length > 0) {
      throw new Error(`Missing required fields: ${missing.join(', ')}`);
    }

    return {
      ...data,
      databases: data?.databases || [],
      pages: data?.pages || [],
      templates: data?.templates || [],
      views: data?.views || []
    };
  }

  /**
   * Fallback workspace structure
   */
  _getFallbackWorkspaceStructure(prompt) {
    return {
      title: "Custom Workspace",
      description: `A workspace created based on: ${prompt}`,
      databases: [
        {
          name: "Tasks",
          icon: "✅",
          properties: [
            { name: "Name", type: "title" },
            { name: "Status", type: "select", options: ["Not Started", "In Progress", "Done"] },
            { name: "Priority", type: "select", options: ["Low", "Medium", "High"] },
            { name: "Due Date", type: "date" },
            { name: "Notes", type: "rich_text" }
          ]
        }
      ],
      pages: [
        {
          name: "Overview",
          icon: "🏠",
          content: "Welcome to your new workspace!",
          type: "page"
        }
      ],
      templates: [],
      views: [
        {
          name: "All Tasks",
          database: "Tasks",
          type: "table"
        }
      ]
    };
  }

  /**
   * Get available models for current provider
   */
  getAvailableModels() {
    switch (this.currentProvider) {
      case 'openRouter':
        return FREE_MODELS?.openRouter;
      case 'gemini':
        return FREE_MODELS?.gemini;
      case 'openai':
        return ['gpt-3.5-turbo', 'gpt-4', 'gpt-4-turbo'];
      default:
        return [];
    }
  }
}

export default new AIService();