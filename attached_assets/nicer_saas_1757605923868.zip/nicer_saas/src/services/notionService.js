import { Client } from '@notionhq/client';

/**
 * Notion Service for workspace creation and management
 */
class NotionService {
  constructor() {
    this.client = null;
    this.isAuthenticated = false;
    this.clientId = import.meta.env?.VITE_NOTION_CLIENT_ID;
  }

  /**
   * Initialize Notion client with access token
   */
  initialize(accessToken) {
    if (!accessToken) {
      throw new Error('Access token is required');
    }

    this.client = new Client({
      auth: accessToken,
    });
    this.isAuthenticated = true;
  }

  /**
   * Get OAuth URL for Notion authentication
   */
  getAuthUrl(redirectUri = window.location?.origin + '/auth/callback') {
    const baseUrl = 'https://api.notion.com/v1/oauth/authorize';
    const params = new URLSearchParams({
      client_id: this.clientId,
      response_type: 'code',
      owner: 'user',
      redirect_uri: redirectUri,
    });

    return `${baseUrl}?${params?.toString()}`;
  }

  /**
   * Exchange authorization code for access token
   */
  async exchangeCodeForToken(code, redirectUri) {
    try {
      const response = await fetch('https://api.notion.com/v1/oauth/token', {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(`${this.clientId}:${import.meta.env?.VITE_NOTION_SECRET_KEY}`)}`,
          'Content-Type': 'application/json',
          'Notion-Version': '2022-06-28'
        },
        body: JSON.stringify({
          grant_type: 'authorization_code',
          code: code,
          redirect_uri: redirectUri,
        }),
      });

      if (!response?.ok) {
        throw new Error(`Token exchange failed: ${response.statusText}`);
      }

      const data = await response?.json();
      
      if (data?.access_token) {
        this.initialize(data?.access_token);
        return {
          accessToken: data?.access_token,
          workspaceId: data?.workspace_id,
          workspaceName: data?.workspace_name,
          workspaceIcon: data?.workspace_icon,
          botId: data?.bot_id,
          owner: data?.owner
        };
      }

      throw new Error('No access token received');
    } catch (error) {
      console.error('Error exchanging code for token:', error);
      throw error;
    }
  }

  /**
   * Create a new workspace page
   */
  async createWorkspace(workspaceData, parentPageId = null) {
    if (!this.isAuthenticated) {
      throw new Error('Not authenticated with Notion');
    }

    try {
      // Create main workspace page
      const workspacePage = await this.client?.pages?.create({
        parent: parentPageId ? 
          { page_id: parentPageId } : 
          { type: 'page_id', page_id: 'root' },
        icon: {
          type: 'emoji',
          emoji: workspaceData?.icon || '🏢'
        },
        properties: {
          title: {
            title: [
              {
                text: {
                  content: workspaceData?.title
                }
              }
            ]
          }
        },
        children: [
          {
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: workspaceData?.description
                  }
                }
              ]
            }
          }
        ]
      });

      const createdElements = {
        workspace: workspacePage,
        databases: [],
        pages: [],
        views: []
      };

      // Create databases
      if (workspaceData?.databases?.length > 0) {
        for (const dbData of workspaceData?.databases) {
          const database = await this.createDatabase(dbData, workspacePage?.id);
          createdElements?.databases?.push(database);
        }
      }

      // Create additional pages
      if (workspaceData?.pages?.length > 0) {
        for (const pageData of workspaceData?.pages) {
          const page = await this.createPage(pageData, workspacePage?.id);
          createdElements?.pages?.push(page);
        }
      }

      return {
        success: true,
        workspace: createdElements,
        url: workspacePage?.url
      };
    } catch (error) {
      console.error('Error creating workspace:', error);
      throw new Error(`Failed to create workspace: ${error.message}`);
    }
  }

  /**
   * Create a database
   */
  async createDatabase(dbData, parentId) {
    const properties = {};
    
    // Process database properties
    dbData?.properties?.forEach(prop => {
      switch (prop?.type) {
        case 'title':
          properties[prop.name] = { title: {} };
          break;
        case 'select':
          properties[prop.name] = {
            select: {
              options: prop?.options?.map(option => ({ name: option, color: 'default' })) || []
            }
          };
          break;
        case 'multi_select':
          properties[prop.name] = {
            multi_select: {
              options: prop?.options?.map(option => ({ name: option, color: 'default' })) || []
            }
          };
          break;
        case 'date':
          properties[prop.name] = { date: {} };
          break;
        case 'rich_text':
          properties[prop.name] = { rich_text: {} };
          break;
        case 'number':
          properties[prop.name] = { number: {} };
          break;
        case 'checkbox':
          properties[prop.name] = { checkbox: {} };
          break;
        case 'url':
          properties[prop.name] = { url: {} };
          break;
        case 'email':
          properties[prop.name] = { email: {} };
          break;
        case 'phone_number':
          properties[prop.name] = { phone_number: {} };
          break;
        default:
          properties[prop.name] = { rich_text: {} };
      }
    });

    const database = await this.client?.databases?.create({
      parent: {
        page_id: parentId
      },
      icon: {
        type: 'emoji',
        emoji: dbData?.icon || '📊'
      },
      title: [
        {
          type: 'text',
          text: {
            content: dbData?.name
          }
        }
      ],
      properties
    });

    return database;
  }

  /**
   * Create a page
   */
  async createPage(pageData, parentId) {
    const page = await this.client?.pages?.create({
      parent: {
        page_id: parentId
      },
      icon: {
        type: 'emoji',
        emoji: pageData?.icon || '📄'
      },
      properties: {
        title: {
          title: [
            {
              text: {
                content: pageData?.name
              }
            }
          ]
        }
      },
      children: [
        {
          object: 'block',
          type: 'paragraph',
          paragraph: {
            rich_text: [
              {
                type: 'text',
                text: {
                  content: pageData?.content || 'Welcome to your new page!'
                }
              }
            ]
          }
        }
      ]
    });

    return page;
  }

  /**
   * Get workspace info
   */
  async getWorkspaceInfo() {
    if (!this.isAuthenticated) {
      throw new Error('Not authenticated with Notion');
    }

    try {
      const response = await this.client?.users?.me();
      return response;
    } catch (error) {
      console.error('Error getting workspace info:', error);
      throw error;
    }
  }

  /**
   * Search for pages and databases
   */
  async search(query, options = {}) {
    if (!this.isAuthenticated) {
      throw new Error('Not authenticated with Notion');
    }

    try {
      const response = await this.client?.search({
        query,
        ...options
      });

      return response?.results;
    } catch (error) {
      console.error('Error searching:', error);
      throw error;
    }
  }

  /**
   * Validate workspace creation
   */
  async validateWorkspaceCreation(workspaceData) {
    const issues = [];

    // Check for required fields
    if (!workspaceData?.title) {
      issues?.push('Workspace title is required');
    }

    if (!workspaceData?.description) {
      issues?.push('Workspace description is required');
    }

    // Validate databases
    if (workspaceData?.databases) {
      workspaceData?.databases?.forEach((db, index) => {
        if (!db?.name) {
          issues?.push(`Database ${index + 1} is missing a name`);
        }

        if (!db?.properties || db?.properties?.length === 0) {
          issues?.push(`Database "${db?.name}" has no properties`);
        }

        // Check for title property
        const hasTitle = db?.properties?.some(prop => prop?.type === 'title');
        if (!hasTitle) {
          issues?.push(`Database "${db?.name}" must have at least one title property`);
        }
      });
    }

    return {
      isValid: issues?.length === 0,
      issues
    };
  }

  /**
   * Check authentication status
   */
  isConnected() {
    return this.isAuthenticated;
  }
}

export default new NotionService();