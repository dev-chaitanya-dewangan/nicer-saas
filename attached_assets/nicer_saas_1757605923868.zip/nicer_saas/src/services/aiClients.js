import OpenAI from 'openai';
import { GoogleGenerativeAI } from '@google/generative-ai';

/**
 * OpenAI Client Configuration
 */
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true, // Required for client-side usage
});

/**
 * OpenRouter Client Configuration (using OpenAI SDK with custom base URL)
 */
const openRouter = new OpenAI({
  apiKey: import.meta.env.VITE_OPENROUTER_API_KEY,
  baseURL: import.meta.env.VITE_OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1',
  dangerouslyAllowBrowser: true,
});

/**
 * Google Gemini Client Configuration
 */
const gemini = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);

/**
 * Free models available on OpenRouter
 */
export const FREE_MODELS = {
  openRouter: [
    'microsoft/wizardlm-2-8x22b',
    'meta-llama/llama-3.2-3b-instruct:free',
    'meta-llama/llama-3.2-1b-instruct:free',
    'qwen/qwen-2-7b-instruct:free',
    'google/gemma-2-9b-it:free',
    'mistralai/mistral-7b-instruct:free',
    'nousresearch/nous-capybara-7b:free',
    'openchat/openchat-7b:free',
    'gryphe/mythomist-7b:free',
    'undi95/toppy-m-7b:free',
    'huggingfaceh4/zephyr-7b-beta:free'
  ],
  gemini: [
    'gemini-1.5-flash',
    'gemini-1.5-flash-8b'
  ]
};

export { openai, openRouter, gemini };