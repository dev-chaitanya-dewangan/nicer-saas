import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import EnhancedWorkspaceGenerator from './components/EnhancedWorkspaceGenerator';

const WorkspaceGenerator = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // Handle incoming state from navigation
  useEffect(() => {
    if (location?.state?.prompt) {
      // The EnhancedWorkspaceGenerator will handle the prompt
      console.log('Received prompt from navigation:', location?.state?.prompt);
    }
  }, [location?.state]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      {/* Main Content */}
      <main className={`
        pt-16 transition-all duration-300 ease-spring min-h-screen
        ${sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'}
      `}>
        <div className="p-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <EnhancedWorkspaceGenerator />
          </motion.div>
        </div>
      </main>
    </div>
  );
};

export default WorkspaceGenerator;