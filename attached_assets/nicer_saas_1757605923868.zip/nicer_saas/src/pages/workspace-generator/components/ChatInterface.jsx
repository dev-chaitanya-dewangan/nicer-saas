import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChatInterface = ({ onPromptSubmit, isGenerating, conversationHistory, onClearHistory }) => {
  const [prompt, setPrompt] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const textareaRef = useRef(null);
  const chatEndRef = useRef(null);

  const examplePrompts = [
    {
      category: 'Business',
      difficulty: 'Beginner',
      time: '2-3 min',
      text: 'Create a simple CRM system to track leads and customers with contact information and deal stages'
    },
    {
      category: 'Project Management',
      difficulty: 'Intermediate',
      time: '5-7 min',
      text: 'Build a comprehensive project management workspace with task boards, team assignments, timeline tracking, and budget monitoring'
    },
    {
      category: 'Content',
      difficulty: 'Advanced',
      time: '8-10 min',
      text: 'Design a content calendar system with editorial workflows, SEO tracking, social media scheduling, and performance analytics'
    },
    {
      category: 'Personal',
      difficulty: 'Beginner',
      time: '1-2 min',
      text: 'Set up a personal habit tracker with daily goals, progress monitoring, and reflection notes'
    }
  ];

  const quickActions = [
    { text: 'Add dark mode support', icon: 'Moon' },
    { text: 'Include mobile responsiveness', icon: 'Smartphone' },
    { text: 'Add user authentication', icon: 'Shield' },
    { text: 'Create dashboard analytics', icon: 'BarChart3' }
  ];

  useEffect(() => {
    if (chatEndRef?.current) {
      chatEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [conversationHistory]);

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (prompt?.trim() && !isGenerating) {
      onPromptSubmit(prompt?.trim());
      setPrompt('');
      setShowSuggestions(false);
    }
  };

  const handlePromptSelect = (selectedPrompt) => {
    setPrompt(selectedPrompt);
    setShowSuggestions(false);
    textareaRef?.current?.focus();
  };

  const handleQuickAction = (action) => {
    const currentPrompt = prompt?.trim();
    const newPrompt = currentPrompt 
      ? `${currentPrompt}. Also, ${action?.text?.toLowerCase()}.`
      : action?.text;
    setPrompt(newPrompt);
    textareaRef?.current?.focus();
  };

  const adjustTextareaHeight = () => {
    if (textareaRef?.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef?.current?.scrollHeight, 120)}px`;
    }
  };

  useEffect(() => {
    adjustTextareaHeight();
  }, [prompt]);

  return (
    <div className="flex flex-col h-full bg-surface">
      {/* Chat Header */}
      <div className="p-4 border-b border-border bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <Icon name="Bot" size={20} color="white" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">AI Workspace Assistant</h3>
              <p className="text-sm text-muted-foreground">Describe your ideal Notion workspace</p>
            </div>
          </div>
          {conversationHistory?.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              iconName="RotateCcw"
              onClick={onClearHistory}
              className="text-muted-foreground hover:text-foreground"
            >
              Clear Chat
            </Button>
          )}
        </div>
      </div>
      {/* Conversation History */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {conversationHistory?.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="MessageSquare" size={24} className="text-muted-foreground" />
            </div>
            <h4 className="font-medium text-foreground mb-2">Start Your Workspace Journey</h4>
            <p className="text-sm text-muted-foreground mb-6 max-w-md mx-auto">
              Describe what kind of workspace you need, and I'll help you create it step by step.
            </p>
            
            {/* Example Prompts */}
            <div className="text-left max-w-2xl mx-auto">
              <h5 className="text-sm font-medium text-foreground mb-3">Try these examples:</h5>
              <div className="grid gap-3">
                {examplePrompts?.map((example, index) => (
                  <button
                    key={index}
                    onClick={() => handlePromptSelect(example?.text)}
                    className="p-4 bg-muted/50 hover:bg-muted rounded-lg text-left transition-colors border border-transparent hover:border-border"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-medium text-primary">{example?.category}</span>
                      <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                        <span className="px-2 py-1 bg-background rounded">{example?.difficulty}</span>
                        <span>{example?.time}</span>
                      </div>
                    </div>
                    <p className="text-sm text-foreground">{example?.text}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <>
            {conversationHistory?.map((message, index) => (
              <div key={index} className={`flex space-x-3 ${message?.type === 'user' ? 'justify-end' : ''}`}>
                {message?.type === 'assistant' && (
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon name="Bot" size={14} color="white" />
                  </div>
                )}
                <div className={`max-w-[80%] ${message?.type === 'user' ? 'order-first' : ''}`}>
                  <div className={`rounded-lg p-4 ${
                    message?.type === 'user' ?'bg-primary text-white ml-auto' :'bg-muted border border-border'
                  }`}>
                    <p className="text-sm whitespace-pre-wrap">{message?.content}</p>
                  </div>
                  <div className={`text-xs text-muted-foreground mt-1 ${
                    message?.type === 'user' ? 'text-right' : 'text-left'
                  }`}>
                    {new Date(message.timestamp)?.toLocaleTimeString()}
                  </div>
                </div>
                {message?.type === 'user' && (
                  <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon name="User" size={14} />
                  </div>
                )}
              </div>
            ))}
            
            {isGenerating && (
              <div className="flex space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon name="Bot" size={14} color="white" />
                </div>
                <div className="bg-muted border border-border rounded-lg p-4">
                  <div className="flex items-center space-x-2">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                    <span className="text-sm text-muted-foreground">Generating workspace...</span>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
        <div ref={chatEndRef} />
      </div>
      {/* Quick Actions */}
      {conversationHistory?.length > 0 && (
        <div className="px-4 py-2 border-t border-border bg-muted/30">
          <div className="flex flex-wrap gap-2">
            {quickActions?.map((action, index) => (
              <button
                key={index}
                onClick={() => handleQuickAction(action)}
                className="flex items-center space-x-2 px-3 py-1.5 bg-background hover:bg-muted rounded-md text-xs text-muted-foreground hover:text-foreground transition-colors border border-border"
              >
                <Icon name={action?.icon} size={12} />
                <span>{action?.text}</span>
              </button>
            ))}
          </div>
        </div>
      )}
      {/* Input Form */}
      <div className="p-4 border-t border-border bg-surface">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="relative">
            <textarea
              ref={textareaRef}
              value={prompt}
              onChange={(e) => setPrompt(e?.target?.value)}
              onFocus={() => setShowSuggestions(true)}
              placeholder="Describe your ideal workspace... (e.g., 'Create a project management system with task tracking and team collaboration')"
              className="w-full p-3 pr-12 border border-border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary bg-background text-foreground placeholder-muted-foreground"
              rows={1}
              style={{ minHeight: '44px', maxHeight: '120px' }}
              disabled={isGenerating}
            />
            <button
              type="button"
              onClick={() => setShowSuggestions(!showSuggestions)}
              className="absolute right-3 top-3 p-1 text-muted-foreground hover:text-foreground transition-colors"
              title="Show suggestions"
            >
              <Icon name="Lightbulb" size={16} />
            </button>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground">
              {prompt?.length}/500 characters
            </div>
            <Button
              type="submit"
              disabled={!prompt?.trim() || isGenerating}
              loading={isGenerating}
              iconName="Send"
              iconPosition="right"
              size="sm"
            >
              {isGenerating ? 'Generating...' : 'Generate Workspace'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;