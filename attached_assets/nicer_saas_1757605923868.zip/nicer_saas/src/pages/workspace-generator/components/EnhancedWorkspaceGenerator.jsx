import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wand2, Upload, Image, CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import AIProviderSelector from '../../../components/ai/AIProviderSelector';
import NotionConnection from '../../../components/notion/NotionConnection';
import aiService from '../../../services/aiService';
import notionService from '../../../services/notionService';

const EnhancedWorkspaceGenerator = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [workspaceData, setWorkspaceData] = useState(null);
  const [generationError, setGenerationError] = useState(null);
  const [deploymentResult, setDeploymentResult] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [isNotionConnected, setIsNotionConnected] = useState(false);
  const [currentProvider, setCurrentProvider] = useState('openRouter');
  const [currentModel, setCurrentModel] = useState('');
  const fileInputRef = useRef(null);

  const handleProviderChange = (provider, model) => {
    setCurrentProvider(provider);
    setCurrentModel(model);
  };

  const handleNotionConnection = (connected, token) => {
    setIsNotionConnected(connected);
    if (!connected) {
      setDeploymentResult(null);
    }
  };

  const handleImageUpload = (event) => {
    const file = event?.target?.files?.[0];
    if (file && file?.type?.startsWith('image/')) {
      setSelectedImage(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    if (fileInputRef?.current) {
      fileInputRef.current.value = '';
    }
  };

  const generateWorkspace = async () => {
    if (!prompt?.trim()) return;

    setIsGenerating(true);
    setGenerationError(null);
    setWorkspaceData(null);

    try {
      let enhancedPrompt = prompt;

      // Analyze image if provided
      if (selectedImage) {
        const imageAnalysis = await aiService?.analyzeImage(
          selectedImage,
          "Analyze this image and extract any relevant information for creating a Notion workspace. Describe what you see and suggest how it could be incorporated into a workspace structure."
        );
        enhancedPrompt = `${prompt}\n\nAdditional context from uploaded image: ${imageAnalysis}`;
      }

      // Generate workspace structure
      const workspace = await aiService?.generateWorkspaceStructure(enhancedPrompt, {
        provider: currentProvider,
        model: currentModel,
        includeViews: true,
        includeTemplates: true,
        maxDatabases: 5,
        maxPages: 10
      });

      setWorkspaceData(workspace);
    } catch (error) {
      console.error('Generation error:', error);
      setGenerationError(error?.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const deployToNotion = async () => {
    if (!workspaceData || !isNotionConnected) return;

    setIsDeploying(true);
    setDeploymentResult(null);

    try {
      // Validate workspace before deployment
      const validation = await notionService?.validateWorkspaceCreation(workspaceData);
      
      if (!validation?.isValid) {
        throw new Error(`Validation failed: ${validation.issues.join(', ')}`);
      }

      // Create workspace in Notion
      const result = await notionService?.createWorkspace(workspaceData);
      
      setDeploymentResult({
        success: true,
        url: result?.url,
        workspace: result?.workspace
      });
    } catch (error) {
      console.error('Deployment error:', error);
      setDeploymentResult({
        success: false,
        error: error?.message
      });
    } finally {
      setIsDeploying(false);
    }
  };

  const regenerateWorkspace = () => {
    generateWorkspace();
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-foreground mb-4">
          AI Workspace Generator
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Create beautiful, functional Notion workspaces with AI. 
          Describe what you need, and we'll build it for you.
        </p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Generation Panel */}
        <div className="space-y-6">
          {/* AI Provider Selection */}
          <div className="bg-background border border-border rounded-xl p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">AI Configuration</h2>
            <AIProviderSelector 
              onProviderChange={handleProviderChange}
              disabled={isGenerating}
            />
            <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-800">
                <strong>Using {currentProvider === 'openRouter' ? 'OpenRouter' : currentProvider}:</strong> 
                {currentProvider === 'openRouter' ? ' Free AI models with high quality outputs' : 
                 currentProvider === 'gemini'? ' Google\'s advanced AI with excellent reasoning' : ' Premium OpenAI models for best results'}
              </p>
            </div>
          </div>

          {/* Input Section */}
          <div className="bg-background border border-border rounded-xl p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Workspace Description</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Describe your ideal workspace
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e?.target?.value)}
                  placeholder="E.g., 'Create a project management workspace for a design team with task tracking, client database, and creative briefs organization'"
                  className="w-full h-32 px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                  disabled={isGenerating}
                />
              </div>

              {/* Image Upload */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Reference Image (Optional)
                </label>
                <div className="flex items-center space-x-3">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    onClick={() => fileInputRef?.current?.click()}
                    disabled={isGenerating}
                    iconName="Upload"
                    iconPosition="left"
                  >
                    Upload Image
                  </Button>
                  
                  {selectedImage && (
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-foreground">{selectedImage?.name}</span>
                      <button
                        onClick={removeImage}
                        className="text-red-500 hover:text-red-700"
                        disabled={isGenerating}
                      >
                        ×
                      </button>
                    </div>
                  )}
                </div>
                
                {selectedImage && (
                  <div className="mt-3">
                    <img
                      src={URL.createObjectURL(selectedImage)}
                      alt="Reference"
                      className="w-32 h-32 object-cover rounded-lg border border-border"
                    />
                  </div>
                )}
              </div>

              <Button
                onClick={generateWorkspace}
                disabled={!prompt?.trim() || isGenerating}
                loading={isGenerating}
                iconName="Wand2"
                iconPosition="left"
                className="w-full"
              >
                {isGenerating ? 'Generating Workspace...' : 'Generate Workspace'}
              </Button>
            </div>
          </div>

          {/* Error Display */}
          <AnimatePresence>
            {generationError && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-red-50 border border-red-200 rounded-lg p-4"
              >
                <div className="flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-red-800">Generation Error</h3>
                    <p className="text-sm text-red-600 mt-1">{generationError}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Preview and Deployment Panel */}
        <div className="space-y-6">
          {/* Notion Connection */}
          <NotionConnection 
            onConnectionChange={handleNotionConnection}
            showConnect={true}
          />

          {/* Workspace Preview */}
          <AnimatePresence>
            {workspaceData && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-background border border-border rounded-xl p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-foreground">Workspace Preview</h2>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={regenerateWorkspace}
                    disabled={isGenerating}
                    iconName="RefreshCw"
                  >
                    Regenerate
                  </Button>
                </div>

                <div className="space-y-4">
                  <div>
                    <h3 className="font-bold text-lg text-foreground">{workspaceData?.title}</h3>
                    <p className="text-muted-foreground">{workspaceData?.description}</p>
                  </div>

                  {/* Databases */}
                  {workspaceData?.databases?.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Databases ({workspaceData?.databases?.length})</h4>
                      <div className="space-y-2">
                        {workspaceData?.databases?.map((db, index) => (
                          <div key={index} className="bg-accent/30 rounded-lg p-3">
                            <div className="flex items-center space-x-2">
                              <span>{db?.icon}</span>
                              <span className="font-medium">{db?.name}</span>
                            </div>
                            <div className="mt-2 text-sm text-muted-foreground">
                              {db?.properties?.length || 0} properties
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Pages */}
                  {workspaceData?.pages?.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Pages ({workspaceData?.pages?.length})</h4>
                      <div className="space-y-2">
                        {workspaceData?.pages?.map((page, index) => (
                          <div key={index} className="bg-accent/30 rounded-lg p-3">
                            <div className="flex items-center space-x-2">
                              <span>{page?.icon}</span>
                              <span className="font-medium">{page?.name}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <Button
                    onClick={deployToNotion}
                    disabled={!isNotionConnected || isDeploying}
                    loading={isDeploying}
                    iconName="ExternalLink"
                    iconPosition="left"
                    className="w-full"
                  >
                    {isDeploying ? 'Creating in Notion...' : 'Deploy to Notion'}
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Deployment Result */}
          <AnimatePresence>
            {deploymentResult && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className={`rounded-xl p-6 ${
                  deploymentResult?.success 
                    ? 'bg-green-50 border border-green-200' :'bg-red-50 border border-red-200'
                }`}
              >
                <div className="flex items-start space-x-3">
                  {deploymentResult?.success ? (
                    <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <h3 className={`font-semibold ${
                      deploymentResult?.success ? 'text-green-800' : 'text-red-800'
                    }`}>
                      {deploymentResult?.success ? '🎉 Workspace Created Successfully!' : 'Deployment Failed'}
                    </h3>
                    
                    {deploymentResult?.success ? (
                      <div className="mt-2 space-y-3">
                        <p className="text-green-700">
                          Your workspace has been created in Notion and is ready to use!
                        </p>
                        <Button
                          as="a"
                          href={deploymentResult?.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          iconName="ExternalLink"
                          iconPosition="right"
                          className="bg-green-600 hover:bg-green-700"
                        >
                          Open in Notion
                        </Button>
                      </div>
                    ) : (
                      <p className="text-red-600 mt-1">{deploymentResult?.error}</p>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default EnhancedWorkspaceGenerator;