import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressIndicator = ({ currentStep, steps, isGenerating }) => {
  const progressSteps = [
    { id: 'input', label: 'Input Requirements', icon: 'MessageSquare' },
    { id: 'configure', label: 'Configure Settings', icon: 'Settings' },
    { id: 'generate', label: 'AI Generation', icon: 'Wand2' },
    { id: 'preview', label: 'Review & Deploy', icon: 'Eye' }
  ];

  const getCurrentStepIndex = () => {
    if (isGenerating) return 2;
    return progressSteps?.findIndex(step => step?.id === currentStep);
  };

  const currentStepIndex = getCurrentStepIndex();

  return (
    <div className="bg-surface border-b border-border p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between">
          {progressSteps?.map((step, index) => (
            <div key={step?.id} className="flex items-center">
              {/* Step Circle */}
              <div className={`
                flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300
                ${index <= currentStepIndex 
                  ? 'bg-primary border-primary text-white' :'bg-background border-border text-muted-foreground'
                }
                ${index === currentStepIndex && isGenerating ? 'animate-pulse' : ''}
              `}>
                {index < currentStepIndex ? (
                  <Icon name="Check" size={16} />
                ) : (
                  <Icon name={step?.icon} size={16} />
                )}
              </div>

              {/* Step Label */}
              <div className="ml-3 hidden sm:block">
                <div className={`text-sm font-medium ${
                  index <= currentStepIndex ? 'text-foreground' : 'text-muted-foreground'
                }`}>
                  {step?.label}
                </div>
                {index === currentStepIndex && isGenerating && (
                  <div className="text-xs text-primary">Processing...</div>
                )}
              </div>

              {/* Connector Line */}
              {index < progressSteps?.length - 1 && (
                <div className={`
                  flex-1 h-0.5 mx-4 transition-all duration-300
                  ${index < currentStepIndex ? 'bg-primary' : 'bg-border'}
                `} />
              )}
            </div>
          ))}
        </div>

        {/* Mobile Step Indicator */}
        <div className="sm:hidden mt-3 text-center">
          <div className="text-sm font-medium text-foreground">
            {progressSteps?.[currentStepIndex]?.label}
          </div>
          {isGenerating && (
            <div className="text-xs text-primary">Processing...</div>
          )}
        </div>

        {/* Progress Bar */}
        <div className="mt-4">
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all duration-500 ease-out"
              style={{ 
                width: `${((currentStepIndex + 1) / progressSteps?.length) * 100}%` 
              }}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>Start</span>
            <span>{Math.round(((currentStepIndex + 1) / progressSteps?.length) * 100)}% Complete</span>
            <span>Deploy</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressIndicator;