import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const PreviewPanel = ({ previewData, isGenerating, onDeploy, onRefine }) => {
  const [activeView, setActiveView] = useState('structure');
  const [selectedDatabase, setSelectedDatabase] = useState(0);

  const viewTabs = [
    { id: 'structure', label: 'Structure', icon: 'Layout' },
    { id: 'database', label: 'Databases', icon: 'Database' },
    { id: 'preview', label: 'Visual Preview', icon: 'Eye' }
  ];

  const mockPreviewData = {
    title: 'Project Management Workspace',
    description: 'Comprehensive project tracking with team collaboration features',
    theme: 'professional',
    structure: [
      {
        type: 'header',
        title: 'Project Dashboard',
        icon: '📊',
        coverImage: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=800&h=300&fit=crop'
      },
      {
        type: 'section',
        title: 'Quick Actions',
        items: [
          { name: 'New Project', icon: 'Plus', type: 'button' },
          { name: 'Team Overview', icon: 'Users', type: 'link' },
          { name: 'Reports', icon: 'BarChart3', type: 'link' }
        ]
      },
      {
        type: 'database',
        title: 'Projects Database',
        icon: '🗂️',
        views: ['Table', 'Board', 'Calendar', 'Timeline'],
        properties: [
          { name: 'Project Name', type: 'title' },
          { name: 'Status', type: 'select', options: ['Planning', 'In Progress', 'Review', 'Completed'] },
          { name: 'Priority', type: 'select', options: ['Low', 'Medium', 'High', 'Critical'] },
          { name: 'Assignee', type: 'person' },
          { name: 'Due Date', type: 'date' },
          { name: 'Progress', type: 'number' },
          { name: 'Budget', type: 'number' }
        ]
      },
      {
        type: 'database',
        title: 'Tasks Database',
        icon: '✅',
        views: ['Table', 'Board', 'List'],
        properties: [
          { name: 'Task Name', type: 'title' },
          { name: 'Project', type: 'relation', relatedTo: 'Projects' },
          { name: 'Status', type: 'select', options: ['To Do', 'In Progress', 'Done'] },
          { name: 'Assignee', type: 'person' },
          { name: 'Due Date', type: 'date' },
          { name: 'Estimated Hours', type: 'number' }
        ]
      }
    ],
    databases: [
      {
        name: 'Projects',
        icon: '🗂️',
        recordCount: 12,
        properties: 7,
        relations: ['Tasks', 'Team Members'],
        sampleData: [
          { name: 'Website Redesign', status: 'In Progress', priority: 'High', assignee: 'Sarah Chen', progress: 65 },
          { name: 'Mobile App Launch', status: 'Planning', priority: 'Critical', assignee: 'Mike Johnson', progress: 15 },
          { name: 'Marketing Campaign', status: 'Review', priority: 'Medium', assignee: 'Lisa Wang', progress: 90 }
        ]
      },
      {
        name: 'Tasks',
        icon: '✅',
        recordCount: 48,
        properties: 6,
        relations: ['Projects'],
        sampleData: [
          { name: 'Design homepage mockup', project: 'Website Redesign', status: 'Done', assignee: 'Sarah Chen' },
          { name: 'Implement user authentication', project: 'Website Redesign', status: 'In Progress', assignee: 'Tom Wilson' },
          { name: 'Create app store listing', project: 'Mobile App Launch', status: 'To Do', assignee: 'Mike Johnson' }
        ]
      }
    ]
  };

  const currentData = previewData || mockPreviewData;

  const StructureView = () => (
    <div className="space-y-4">
      {currentData?.structure?.map((item, index) => (
        <div key={index} className="border border-border rounded-lg p-4 bg-surface">
          {item?.type === 'header' && (
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{item?.icon}</span>
                <div>
                  <h3 className="font-semibold text-foreground">{item?.title}</h3>
                  <p className="text-sm text-muted-foreground">Page Header</p>
                </div>
              </div>
              {item?.coverImage && (
                <div className="w-full h-32 bg-muted rounded-lg overflow-hidden">
                  <Image 
                    src={item?.coverImage} 
                    alt="Cover" 
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          )}
          
          {item?.type === 'section' && (
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Icon name="Layout" size={16} className="text-primary" />
                <h4 className="font-medium text-foreground">{item?.title}</h4>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {item?.items?.map((subItem, subIndex) => (
                  <div key={subIndex} className="flex items-center space-x-2 p-2 bg-muted rounded-md">
                    <Icon name={subItem?.icon} size={14} />
                    <span className="text-sm text-foreground">{subItem?.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {item?.type === 'database' && (
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <span className="text-xl">{item?.icon}</span>
                <div>
                  <h4 className="font-medium text-foreground">{item?.title}</h4>
                  <p className="text-sm text-muted-foreground">
                    {item?.properties?.length} properties • {item?.views?.length} views
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {item?.views?.map((view, viewIndex) => (
                  <span key={viewIndex} className="px-2 py-1 bg-primary/10 text-primary text-xs rounded">
                    {view}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );

  const DatabaseView = () => (
    <div className="space-y-4">
      <div className="flex space-x-2 border-b border-border">
        {currentData?.databases?.map((db, index) => (
          <button
            key={index}
            onClick={() => setSelectedDatabase(index)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              selectedDatabase === index
                ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <span className="mr-2">{db?.icon}</span>
            {db?.name}
          </button>
        ))}
      </div>

      {currentData?.databases?.[selectedDatabase] && (
        <div className="space-y-4">
          <div className="bg-surface border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{currentData?.databases?.[selectedDatabase]?.icon}</span>
                <div>
                  <h3 className="font-semibold text-foreground">{currentData?.databases?.[selectedDatabase]?.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {currentData?.databases?.[selectedDatabase]?.recordCount} records • 
                    {currentData?.databases?.[selectedDatabase]?.properties} properties
                  </p>
                </div>
              </div>
              <div className="flex space-x-2">
                {currentData?.databases?.[selectedDatabase]?.relations?.map((relation, index) => (
                  <span key={index} className="px-2 py-1 bg-accent/10 text-accent text-xs rounded">
                    → {relation}
                  </span>
                ))}
              </div>
            </div>

            {/* Sample Data Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    {currentData?.databases?.[selectedDatabase]?.sampleData?.[0] && 
                      Object.keys(currentData?.databases?.[selectedDatabase]?.sampleData?.[0])?.map((key) => (
                        <th key={key} className="text-left p-2 font-medium text-muted-foreground capitalize">
                          {key?.replace(/([A-Z])/g, ' $1')?.trim()}
                        </th>
                      ))
                    }
                  </tr>
                </thead>
                <tbody>
                  {currentData?.databases?.[selectedDatabase]?.sampleData?.map((row, index) => (
                    <tr key={index} className="border-b border-border/50">
                      {Object.values(row)?.map((value, valueIndex) => (
                        <td key={valueIndex} className="p-2 text-foreground">
                          {typeof value === 'string' && value?.length > 30 
                            ? `${value?.substring(0, 30)}...` 
                            : value
                          }
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const VisualPreview = () => (
    <div className="space-y-4">
      <div className="bg-surface border border-border rounded-lg overflow-hidden">
        {/* Mock Notion Interface */}
        <div className="bg-muted/50 p-3 border-b border-border">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="ml-4 text-sm text-muted-foreground">notion.so/workspace-preview</span>
          </div>
        </div>
        
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="space-y-4">
            <div className="w-full h-24 bg-gradient-to-r from-primary/20 to-accent/20 rounded-lg flex items-center justify-center">
              <span className="text-3xl">📊</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">{currentData?.title}</h1>
              <p className="text-muted-foreground">{currentData?.description}</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 bg-muted/50 rounded-lg text-center">
              <Icon name="Plus" size={20} className="mx-auto mb-2 text-primary" />
              <span className="text-sm text-foreground">New Project</span>
            </div>
            <div className="p-3 bg-muted/50 rounded-lg text-center">
              <Icon name="Users" size={20} className="mx-auto mb-2 text-primary" />
              <span className="text-sm text-foreground">Team</span>
            </div>
            <div className="p-3 bg-muted/50 rounded-lg text-center">
              <Icon name="BarChart3" size={20} className="mx-auto mb-2 text-primary" />
              <span className="text-sm text-foreground">Reports</span>
            </div>
          </div>

          {/* Database Preview */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <span className="text-xl">🗂️</span>
              <h3 className="font-semibold text-foreground">Projects Database</h3>
            </div>
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="grid grid-cols-4 gap-4 text-sm">
                <div className="font-medium text-muted-foreground">Project</div>
                <div className="font-medium text-muted-foreground">Status</div>
                <div className="font-medium text-muted-foreground">Priority</div>
                <div className="font-medium text-muted-foreground">Progress</div>
                
                <div className="text-foreground">Website Redesign</div>
                <div className="text-blue-600">In Progress</div>
                <div className="text-red-600">High</div>
                <div className="text-foreground">65%</div>
                
                <div className="text-foreground">Mobile App</div>
                <div className="text-yellow-600">Planning</div>
                <div className="text-red-600">Critical</div>
                <div className="text-foreground">15%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  if (isGenerating) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/30">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
            <Icon name="Wand2" size={24} className="text-primary animate-pulse" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Generating Your Workspace</h3>
            <p className="text-sm text-muted-foreground">This may take a few minutes...</p>
          </div>
          <div className="flex justify-center space-x-1">
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-muted/30">
      {/* Header */}
      <div className="p-4 border-b border-border bg-surface">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Icon name="Eye" size={20} className="text-primary" />
            <div>
              <h3 className="font-semibold text-foreground">Workspace Preview</h3>
              <p className="text-sm text-muted-foreground">Review before deployment</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              iconName="RefreshCw"
              onClick={onRefine}
            >
              Refine
            </Button>
            <Button
              size="sm"
              iconName="Rocket"
              iconPosition="left"
              onClick={onDeploy}
            >
              Deploy to Notion
            </Button>
          </div>
        </div>
      </div>
      {/* View Tabs */}
      <div className="border-b border-border bg-surface">
        <div className="flex space-x-1 p-2">
          {viewTabs?.map((tab) => (
            <button
              key={tab?.id}
              onClick={() => setActiveView(tab?.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeView === tab?.id
                  ? 'bg-primary text-white' :'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <Icon name={tab?.icon} size={16} />
              <span>{tab?.label}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeView === 'structure' && <StructureView />}
        {activeView === 'database' && <DatabaseView />}
        {activeView === 'preview' && <VisualPreview />}
      </div>
    </div>
  );
};

export default PreviewPanel;