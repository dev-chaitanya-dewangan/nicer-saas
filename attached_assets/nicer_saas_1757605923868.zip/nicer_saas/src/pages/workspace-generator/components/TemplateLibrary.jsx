import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Image from '../../../components/AppImage';

const TemplateLibrary = ({ onTemplateSelect, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { value: 'all', label: 'All Templates' },
    { value: 'business', label: 'Business' },
    { value: 'creative', label: 'Creative' },
    { value: 'personal', label: 'Personal' },
    { value: 'education', label: 'Education' }
  ];

  const templates = [
    {
      id: 'crm-basic',
      name: 'Basic CRM System',
      description: 'Simple customer relationship management with contacts, deals, and pipeline tracking',
      category: 'business',
      difficulty: 'Beginner',
      estimatedTime: '2-3 min',
      features: ['Contact Management', 'Deal Pipeline', 'Activity Tracking'],
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=200&fit=crop',
      prompt: 'Create a basic CRM system with contact management, deal pipeline tracking, and activity logs. Include fields for company information, contact details, deal stages, and follow-up reminders.'
    },
    {
      id: 'project-management',
      name: 'Project Management Hub',
      description: 'Comprehensive project tracking with tasks, timelines, and team collaboration',
      category: 'business',
      difficulty: 'Intermediate',
      estimatedTime: '5-7 min',
      features: ['Task Management', 'Timeline View', 'Team Collaboration', 'Budget Tracking'],
      image: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=200&fit=crop',
      prompt: 'Build a project management workspace with task boards, Gantt charts, team assignments, milestone tracking, budget monitoring, and progress reporting. Include multiple views and automated workflows.'
    },
    {
      id: 'content-calendar',
      name: 'Content Calendar',
      description: 'Editorial calendar with content planning, SEO tracking, and publishing workflows',
      category: 'creative',
      difficulty: 'Advanced',
      estimatedTime: '8-10 min',
      features: ['Editorial Calendar', 'SEO Tracking', 'Social Media Planning', 'Content Analytics'],
      image: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=200&fit=crop',
      prompt: 'Design a comprehensive content calendar with editorial workflows, SEO optimization tracking, social media scheduling, content performance analytics, and team collaboration features.'
    },
    {
      id: 'habit-tracker',
      name: 'Personal Habit Tracker',
      description: 'Daily habit tracking with goals, streaks, and progress visualization',
      category: 'personal',
      difficulty: 'Beginner',
      estimatedTime: '1-2 min',
      features: ['Daily Tracking', 'Streak Counter', 'Goal Setting', 'Progress Charts'],
      image: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=400&h=200&fit=crop',
      prompt: 'Create a personal habit tracker with daily check-ins, streak counters, goal setting, progress visualization, and reflection notes. Include motivational features and habit categories.'
    },
    {
      id: 'student-planner',
      name: 'Student Academic Planner',
      description: 'Academic planning with courses, assignments, grades, and study schedules',
      category: 'education',
      difficulty: 'Intermediate',
      estimatedTime: '4-6 min',
      features: ['Course Management', 'Assignment Tracking', 'Grade Calculator', 'Study Schedule'],
      image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=200&fit=crop',
      prompt: 'Build a student academic planner with course management, assignment tracking, grade calculations, study schedules, exam preparation, and academic goal setting.'
    },
    {
      id: 'freelance-business',
      name: 'Freelance Business Manager',
      description: 'Complete freelance business management with clients, projects, and invoicing',
      category: 'business',
      difficulty: 'Advanced',
      estimatedTime: '10-12 min',
      features: ['Client Management', 'Project Tracking', 'Invoice Generation', 'Time Tracking'],
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=200&fit=crop',
      prompt: 'Create a comprehensive freelance business management system with client databases, project tracking, time logging, invoice generation, expense tracking, and financial reporting.'
    },
    {
      id: 'recipe-collection',
      name: 'Recipe Collection & Meal Planner',
      description: 'Recipe database with meal planning, shopping lists, and nutrition tracking',
      category: 'personal',
      difficulty: 'Intermediate',
      estimatedTime: '3-5 min',
      features: ['Recipe Database', 'Meal Planning', 'Shopping Lists', 'Nutrition Info'],
      image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=200&fit=crop',
      prompt: 'Design a recipe collection and meal planning system with recipe database, weekly meal planning, automatic shopping list generation, nutrition tracking, and cooking timers.'
    },
    {
      id: 'event-planning',
      name: 'Event Planning Workspace',
      description: 'Complete event management with vendors, budgets, timelines, and guest lists',
      category: 'business',
      difficulty: 'Advanced',
      estimatedTime: '7-9 min',
      features: ['Vendor Management', 'Budget Tracking', 'Timeline Planning', 'Guest Management'],
      image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=400&h=200&fit=crop',
      prompt: 'Build an event planning workspace with vendor management, budget tracking, timeline planning, guest list management, task assignments, and event day coordination tools.'
    }
  ];

  const filteredTemplates = templates?.filter(template => {
    const matchesCategory = selectedCategory === 'all' || template?.category === selectedCategory;
    const matchesSearch = template?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
                         template?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Beginner': return 'text-green-600 bg-green-100';
      case 'Intermediate': return 'text-yellow-600 bg-yellow-100';
      case 'Advanced': return 'text-red-600 bg-red-100';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  const handleTemplateSelect = (template) => {
    onTemplateSelect(template?.prompt);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-surface rounded-lg shadow-floating max-w-6xl w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Icon name="Layout" size={24} className="text-primary" />
              <div>
                <h2 className="text-xl font-semibold text-foreground">Template Library</h2>
                <p className="text-sm text-muted-foreground">Choose a pre-built template to get started quickly</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              iconName="X"
              onClick={onClose}
            />
          </div>
        </div>

        {/* Filters */}
        <div className="p-6 border-b border-border bg-muted/30">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon name="Search" size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search templates..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e?.target?.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <Select
                options={categories}
                value={selectedCategory}
                onChange={setSelectedCategory}
                placeholder="All Categories"
              />
            </div>
          </div>
        </div>

        {/* Templates Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTemplates?.map((template) => (
              <div key={template?.id} className="bg-background border border-border rounded-lg overflow-hidden hover:shadow-card transition-shadow">
                {/* Template Image */}
                <div className="w-full h-32 bg-muted overflow-hidden">
                  <Image 
                    src={template?.image} 
                    alt={template?.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Template Content */}
                <div className="p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <h3 className="font-semibold text-foreground">{template?.name}</h3>
                    <span className={`px-2 py-1 text-xs rounded-full ${getDifficultyColor(template?.difficulty)}`}>
                      {template?.difficulty}
                    </span>
                  </div>

                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {template?.description}
                  </p>

                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Icon name="Clock" size={12} />
                      <span>{template?.estimatedTime}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name="Tag" size={12} />
                      <span className="capitalize">{template?.category}</span>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-medium text-foreground">Key Features:</h4>
                    <div className="flex flex-wrap gap-1">
                      {template?.features?.slice(0, 3)?.map((feature, index) => (
                        <span key={index} className="px-2 py-1 bg-muted text-xs text-muted-foreground rounded">
                          {feature}
                        </span>
                      ))}
                      {template?.features?.length > 3 && (
                        <span className="px-2 py-1 bg-muted text-xs text-muted-foreground rounded">
                          +{template?.features?.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Action Button */}
                  <Button
                    onClick={() => handleTemplateSelect(template)}
                    variant="outline"
                    size="sm"
                    iconName="Wand2"
                    iconPosition="left"
                    fullWidth
                    className="mt-4"
                  >
                    Use This Template
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {filteredTemplates?.length === 0 && (
            <div className="text-center py-12">
              <Icon name="Search" size={48} className="mx-auto text-muted-foreground mb-4" />
              <h3 className="font-medium text-foreground mb-2">No templates found</h3>
              <p className="text-sm text-muted-foreground">
                Try adjusting your search or category filter
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border bg-muted/30">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              {filteredTemplates?.length} template{filteredTemplates?.length !== 1 ? 's' : ''} available
            </div>
            <Button
              variant="ghost"
              onClick={onClose}
            >
              Cancel
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplateLibrary;