import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const ConfigurationPanel = ({ configuration, onConfigurationChange, onGenerate, isGenerating }) => {
  const [expandedSections, setExpandedSections] = useState({
    theme: true,
    layout: false,
    database: false,
    advanced: false
  });

  const themeOptions = [
    { value: 'professional', label: 'Professional', description: 'Clean, corporate aesthetic' },
    { value: 'pastel', label: 'Pastel', description: 'Soft, calming colors' },
    { value: 'dark', label: 'Dark', description: 'Dark mode optimized' },
    { value: 'fun', label: 'Fun', description: 'Bright, energetic colors' },
    { value: 'light', label: 'Light', description: 'Minimal, clean design' },
    { value: 'cheerful', label: 'Cheerful', description: 'Warm, inviting tones' },
    { value: 'loving', label: 'Loving', description: 'Romantic, soft palette' },
    { value: 'soft', label: 'Soft', description: 'Gentle, muted colors' },
    { value: 'rough', label: 'Rough', description: 'Bold, industrial feel' }
  ];

  const densityOptions = [
    { value: 'compact', label: 'Compact', description: 'More content, less spacing' },
    { value: 'spacious', label: 'Spacious', description: 'More breathing room' }
  ];

  const viewTypeOptions = [
    { value: 'table', label: 'Table View' },
    { value: 'board', label: 'Kanban Board' },
    { value: 'calendar', label: 'Calendar View' },
    { value: 'gallery', label: 'Gallery View' },
    { value: 'list', label: 'List View' },
    { value: 'timeline', label: 'Timeline View' }
  ];

  const relationshipOptions = [
    { value: 'one-to-one', label: 'One-to-One' },
    { value: 'one-to-many', label: 'One-to-Many' },
    { value: 'many-to-many', label: 'Many-to-Many' }
  ];

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev?.[section]
    }));
  };

  const handleConfigChange = (key, value) => {
    onConfigurationChange({
      ...configuration,
      [key]: value
    });
  };

  const handleArrayConfigChange = (key, value, checked) => {
    const currentArray = configuration?.[key] || [];
    if (checked) {
      handleConfigChange(key, [...currentArray, value]);
    } else {
      handleConfigChange(key, currentArray?.filter(item => item !== value));
    }
  };

  const ConfigSection = ({ title, icon, sectionKey, children }) => (
    <div className="border border-border rounded-lg bg-surface">
      <button
        onClick={() => toggleSection(sectionKey)}
        className="w-full p-4 flex items-center justify-between hover:bg-muted/50 transition-colors"
      >
        <div className="flex items-center space-x-3">
          <Icon name={icon} size={18} className="text-primary" />
          <span className="font-medium text-foreground">{title}</span>
        </div>
        <Icon 
          name={expandedSections?.[sectionKey] ? 'ChevronUp' : 'ChevronDown'} 
          size={16} 
          className="text-muted-foreground" 
        />
      </button>
      {expandedSections?.[sectionKey] && (
        <div className="p-4 pt-0 border-t border-border">
          {children}
        </div>
      )}
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-muted/30">
      {/* Header */}
      <div className="p-4 border-b border-border bg-surface">
        <div className="flex items-center space-x-3">
          <Icon name="Settings" size={20} className="text-primary" />
          <div>
            <h3 className="font-semibold text-foreground">Workspace Configuration</h3>
            <p className="text-sm text-muted-foreground">Customize your workspace settings</p>
          </div>
        </div>
      </div>
      {/* Configuration Sections */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Theme Configuration */}
        <ConfigSection title="Theme & Appearance" icon="Palette" sectionKey="theme">
          <div className="space-y-4">
            <Select
              label="Theme Style"
              description="Choose the visual theme for your workspace"
              options={themeOptions}
              value={configuration?.theme}
              onChange={(value) => handleConfigChange('theme', value)}
              searchable
            />
            
            <Select
              label="Layout Density"
              description="Control spacing and content density"
              options={densityOptions}
              value={configuration?.density}
              onChange={(value) => handleConfigChange('density', value)}
            />

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Additional Options</label>
              <div className="space-y-2">
                <Checkbox
                  label="Include cover images"
                  description="Add visual headers to pages"
                  checked={configuration?.includeCoverImages || false}
                  onChange={(e) => handleConfigChange('includeCoverImages', e?.target?.checked)}
                />
                <Checkbox
                  label="Use custom icons"
                  description="Apply themed icons throughout"
                  checked={configuration?.useCustomIcons || false}
                  onChange={(e) => handleConfigChange('useCustomIcons', e?.target?.checked)}
                />
              </div>
            </div>
          </div>
        </ConfigSection>

        {/* Layout Configuration */}
        <ConfigSection title="Layout & Structure" icon="Layout" sectionKey="layout">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Default View Types</label>
              <p className="text-xs text-muted-foreground">Select which views to include by default</p>
              <div className="grid grid-cols-2 gap-2">
                {viewTypeOptions?.map((view) => (
                  <Checkbox
                    key={view?.value}
                    label={view?.label}
                    checked={(configuration?.defaultViews || [])?.includes(view?.value)}
                    onChange={(e) => handleArrayConfigChange('defaultViews', view?.value, e?.target?.checked)}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Structure Options</label>
              <div className="space-y-2">
                <Checkbox
                  label="Include hierarchical sections"
                  description="Add dividers and section headers"
                  checked={configuration?.includeHierarchy || false}
                  onChange={(e) => handleConfigChange('includeHierarchy', e?.target?.checked)}
                />
                <Checkbox
                  label="Generate sample data"
                  description="Populate with realistic example content"
                  checked={configuration?.includeSampleData || true}
                  onChange={(e) => handleConfigChange('includeSampleData', e?.target?.checked)}
                />
              </div>
            </div>
          </div>
        </ConfigSection>

        {/* Database Configuration */}
        <ConfigSection title="Database & Relations" icon="Database" sectionKey="database">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Relationship Types</label>
              <p className="text-xs text-muted-foreground">Enable database relationship creation</p>
              <div className="space-y-2">
                {relationshipOptions?.map((relation) => (
                  <Checkbox
                    key={relation?.value}
                    label={relation?.label}
                    checked={(configuration?.enabledRelations || [])?.includes(relation?.value)}
                    onChange={(e) => handleArrayConfigChange('enabledRelations', relation?.value, e?.target?.checked)}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Advanced Properties</label>
              <div className="space-y-2">
                <Checkbox
                  label="Generate formulas"
                  description="Create calculated fields automatically"
                  checked={configuration?.generateFormulas || false}
                  onChange={(e) => handleConfigChange('generateFormulas', e?.target?.checked)}
                />
                <Checkbox
                  label="Include rollup properties"
                  description="Add summary fields from related databases"
                  checked={configuration?.includeRollups || false}
                  onChange={(e) => handleConfigChange('includeRollups', e?.target?.checked)}
                />
                <Checkbox
                  label="Add status properties"
                  description="Include workflow status fields"
                  checked={configuration?.includeStatus || true}
                  onChange={(e) => handleConfigChange('includeStatus', e?.target?.checked)}
                />
              </div>
            </div>
          </div>
        </ConfigSection>

        {/* Advanced Configuration */}
        <ConfigSection title="Advanced Options" icon="Zap" sectionKey="advanced">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Generation Options</label>
              <div className="space-y-2">
                <Checkbox
                  label="Multi-database workspace"
                  description="Create interconnected database systems"
                  checked={configuration?.multiDatabase || false}
                  onChange={(e) => handleConfigChange('multiDatabase', e?.target?.checked)}
                />
                <Checkbox
                  label="Include automation templates"
                  description="Add workflow automation suggestions"
                  checked={configuration?.includeAutomation || false}
                  onChange={(e) => handleConfigChange('includeAutomation', e?.target?.checked)}
                />
                <Checkbox
                  label="Generate API documentation"
                  description="Create integration guides"
                  checked={configuration?.includeApiDocs || false}
                  onChange={(e) => handleConfigChange('includeApiDocs', e?.target?.checked)}
                />
              </div>
            </div>

            <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
              <div className="flex items-start space-x-2">
                <Icon name="AlertTriangle" size={16} className="text-warning mt-0.5" />
                <div className="text-xs">
                  <p className="font-medium text-warning">Advanced Features</p>
                  <p className="text-muted-foreground">Some options may increase generation time and require Pro subscription.</p>
                </div>
              </div>
            </div>
          </div>
        </ConfigSection>
      </div>
      {/* Generate Button */}
      <div className="p-4 border-t border-border bg-surface">
        <Button
          onClick={onGenerate}
          disabled={isGenerating}
          loading={isGenerating}
          iconName="Wand2"
          iconPosition="left"
          fullWidth
          size="lg"
        >
          {isGenerating ? 'Generating Workspace...' : 'Generate with Configuration'}
        </Button>
        
        <div className="mt-2 text-xs text-center text-muted-foreground">
          Estimated time: 2-5 minutes depending on complexity
        </div>
      </div>
    </div>
  );
};

export default ConfigurationPanel;