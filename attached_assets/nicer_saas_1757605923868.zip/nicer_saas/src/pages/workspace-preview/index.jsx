import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import PreviewHeader from './components/PreviewHeader';
import PreviewNavigation from './components/PreviewNavigation';
import DatabasePreview from './components/DatabasePreview';
import FormulaInspector from './components/FormulaInspector';
import DeploymentModal from './components/DeploymentModal';
import WorkspaceLayout from './components/WorkspaceLayout';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const WorkspacePreview = () => {
  const navigate = useNavigate();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeSection, setActiveSection] = useState('overview');
  const [selectedTheme, setSelectedTheme] = useState('professional');
  const [layoutDensity, setLayoutDensity] = useState('spacious');
  const [showFormulaInspector, setShowFormulaInspector] = useState(false);
  const [showDeploymentModal, setShowDeploymentModal] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);

  // Mock workspace data
  const workspaceData = {
    title: "Project Management Hub",
    description: "Comprehensive workspace for managing projects, tasks, and team collaboration",
    icon: "FolderKanban",
    sections: [
      {
        id: 'intro',
        type: 'text',
        title: 'Welcome to Your Project Hub',
        icon: 'Home',
        description: 'Your centralized workspace for project management',
        content: `This workspace provides everything you need to manage projects effectively. Track tasks, monitor progress, collaborate with team members, and maintain project documentation all in one place.`
      },
      {
        id: 'getting-started',
        type: 'callout',
        title: 'Getting Started',
        icon: 'Rocket',
        calloutIcon: 'Lightbulb',
        calloutTitle: 'Quick Start Guide',
        content: `Begin by adding your first project in the Projects database. Then create tasks, assign team members, and set up your project timeline. Use the dashboard views to monitor progress and identify bottlenecks.`
      },
      {
        id: 'divider1',
        type: 'divider',
        content: 'Project Databases'
      },
      {
        id: 'features',
        type: 'checklist',
        title: 'Key Features',
        icon: 'CheckSquare',
        items: [
          { text: 'Project tracking with status updates', checked: true },
          { text: 'Task management with priorities and deadlines', checked: true },
          { text: 'Team member assignments and workload tracking', checked: true },
          { text: 'Automated progress calculations', checked: true },
          { text: 'Timeline and milestone tracking', checked: false },
          { text: 'Resource allocation and budget monitoring', checked: false }
        ]
      }
    ]
  };

  const mockDatabases = [
    {
      id: 'projects',
      name: 'Projects',
      description: 'Track all your projects with status, timeline, and team assignments',
      icon: 'FolderOpen',
      properties: [
        { id: 'name', name: 'Project Name', type: 'title', icon: 'Type' },
        { id: 'status', name: 'Status', type: 'status', icon: 'Circle' },
        { id: 'owner', name: 'Project Owner', type: 'person', icon: 'User' },
        { id: 'deadline', name: 'Deadline', type: 'date', icon: 'Calendar' },
        { id: 'progress', name: 'Progress', type: 'formula', icon: 'TrendingUp' }
      ],
      sampleData: [
        {
          name: 'Website Redesign',
          status: 'In Progress',
          owner: 'Sarah Johnson',
          deadline: '2025-01-15',
          progress: '65%'
        },
        {
          name: 'Mobile App Launch',
          status: 'Planning',
          owner: 'Mike Chen',
          deadline: '2025-02-28',
          progress: '25%'
        },
        {
          name: 'Marketing Campaign',
          status: 'Review',
          owner: 'Emily Davis',
          deadline: '2025-01-30',
          progress: '85%'
        }
      ]
    },
    {
      id: 'tasks',
      name: 'Tasks',
      description: 'Detailed task management with priorities and dependencies',
      icon: 'CheckSquare',
      properties: [
        { id: 'task', name: 'Task', type: 'title', icon: 'Type' },
        { id: 'project', name: 'Project', type: 'relation', icon: 'Link' },
        { id: 'assignee', name: 'Assignee', type: 'person', icon: 'User' },
        { id: 'priority', name: 'Priority', type: 'status', icon: 'AlertTriangle' },
        { id: 'due', name: 'Due Date', type: 'date', icon: 'Calendar' }
      ],
      sampleData: [
        {
          task: 'Design homepage mockup',
          project: 'Website Redesign',
          assignee: 'Alex Rivera',
          priority: 'High',
          due: '2025-01-12'
        },
        {
          task: 'Set up development environment',
          project: 'Mobile App Launch',
          assignee: 'Jordan Kim',
          priority: 'Medium',
          due: '2025-01-18'
        },
        {
          task: 'Create social media content',
          project: 'Marketing Campaign',
          assignee: 'Taylor Brown',
          priority: 'High',
          due: '2025-01-14'
        }
      ]
    },
    {
      id: 'team',
      name: 'Team Members',
      description: 'Team directory with roles, skills, and current workload',
      icon: 'Users',
      properties: [
        { id: 'name', name: 'Name', type: 'title', icon: 'Type' },
        { id: 'role', name: 'Role', type: 'status', icon: 'Briefcase' },
        { id: 'email', name: 'Email', type: 'email', icon: 'Mail' },
        { id: 'workload', name: 'Current Workload', type: 'formula', icon: 'BarChart' },
        { id: 'skills', name: 'Skills', type: 'multi_select', icon: 'Star' }
      ],
      sampleData: [
        {
          name: 'Sarah Johnson',
          role: 'Project Manager',
          email: 'sarah@company.com',
          workload: '75%',
          skills: 'Leadership, Planning'
        },
        {
          name: 'Alex Rivera',
          role: 'UI Designer',
          email: 'alex@company.com',
          workload: '60%',
          skills: 'Design, Prototyping'
        },
        {
          name: 'Jordan Kim',
          role: 'Developer',
          email: 'jordan@company.com',
          workload: '80%',
          skills: 'React, Node.js'
        }
      ]
    }
  ];

  const mockFormulas = [
    {
      id: 'progress-calc',
      name: 'Project Progress',
      type: 'Number',
      description: 'Calculates project completion percentage based on completed tasks',
      expression: 'round(prop("Completed Tasks") / prop("Total Tasks") * 100)',
      example: '65% (13 of 20 tasks completed)'
    },
    {
      id: 'days-remaining',
      name: 'Days Until Deadline',
      type: 'Number',
      description: 'Shows remaining days until project deadline',
      expression: 'dateBetween(prop("Deadline"), now(), "days")',
      example: '23 days remaining'
    },
    {
      id: 'workload-calc',
      name: 'Team Member Workload',
      type: 'Number',
      description: 'Calculates current workload percentage for team members',
      expression: 'round(prop("Active Tasks") / prop("Capacity") * 100)',
      example: '75% (6 of 8 task capacity)'
    }
  ];

  const mockRollups = [
    {
      id: 'project-tasks',
      name: 'Total Project Tasks',
      function: 'Count',
      description: 'Counts total number of tasks assigned to each project',
      sourceDatabase: 'Tasks',
      targetProperty: 'Project',
      example: '15 tasks total'
    },
    {
      id: 'completed-tasks',
      name: 'Completed Tasks',
      function: 'Count',
      description: 'Counts completed tasks for progress calculation',
      sourceDatabase: 'Tasks',
      targetProperty: 'Status = Done',
      example: '9 completed tasks'
    }
  ];

  const sections = [
    { id: 'overview', name: 'Overview', icon: 'Home', count: null },
    { id: 'databases', name: 'Databases', icon: 'Database', count: mockDatabases?.length },
    { id: 'formulas', name: 'Formulas', icon: 'Calculator', count: mockFormulas?.length + mockRollups?.length }
  ];

  const handleThemeChange = (theme) => {
    setSelectedTheme(theme);
  };

  const handleDeploy = () => {
    setShowDeploymentModal(true);
  };

  const handleDeployConfirm = () => {
    setIsDeploying(true);
    // Deployment logic would go here
  };

  const handleModify = () => {
    navigate('/workspace-generator');
  };

  const handleSave = () => {
    // Save workspace logic would go here
    console.log('Workspace saved');
  };

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'overview':
        return (
          <div className="space-y-6">
            <WorkspaceLayout 
              workspace={workspaceData} 
              theme={selectedTheme} 
              density={layoutDensity} 
            />
          </div>
        );

      case 'databases':
        return (
          <div className="space-y-6">
            {mockDatabases?.map((database) => (
              <DatabasePreview
                key={database?.id}
                database={database}
                theme={selectedTheme}
                density={layoutDensity}
              />
            ))}
          </div>
        );

      case 'formulas':
        return (
          <div className="space-y-6">
            <div className="bg-surface border border-border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-foreground">Advanced Configurations</h3>
                  <p className="text-sm text-muted-foreground">
                    Review formulas, rollups, and property configurations
                  </p>
                </div>
                <Button
                  variant="outline"
                  iconName="Code"
                  iconPosition="left"
                  onClick={() => setShowFormulaInspector(true)}
                >
                  Inspect Details
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-muted/30 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="Calculator" size={20} className="text-primary" />
                    <h4 className="font-medium text-foreground">Formulas</h4>
                  </div>
                  <p className="text-2xl font-bold text-foreground mb-1">{mockFormulas?.length}</p>
                  <p className="text-sm text-muted-foreground">Advanced calculations configured</p>
                </div>

                <div className="bg-muted/30 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="BarChart3" size={20} className="text-accent" />
                    <h4 className="font-medium text-foreground">Rollups</h4>
                  </div>
                  <p className="text-2xl font-bold text-foreground mb-1">{mockRollups?.length}</p>
                  <p className="text-sm text-muted-foreground">Cross-database relationships</p>
                </div>
              </div>

              <div className="mt-4 p-4 bg-primary/10 border border-primary/20 rounded-lg">
                <div className="flex items-start space-x-2">
                  <Icon name="Info" size={16} className="text-primary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-primary mb-1">Smart Automation</p>
                    <p className="text-sm text-foreground">
                      Your workspace includes automated calculations for project progress, 
                      team workload distribution, and deadline tracking.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={sidebarCollapsed} 
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)} 
      />
      <main className={`
        transition-all duration-300 ease-spring pt-16
        ${sidebarCollapsed ? 'ml-16' : 'ml-64'}
      `}>
        <PreviewHeader
          workspaceName={workspaceData?.title}
          theme={selectedTheme}
          onThemeChange={handleThemeChange}
          onDeploy={handleDeploy}
          onModify={handleModify}
          onSave={handleSave}
          isDeploying={isDeploying}
        />

        <PreviewNavigation
          sections={sections}
          activeSection={activeSection}
          onSectionChange={setActiveSection}
          density={layoutDensity}
          onDensityChange={setLayoutDensity}
        />

        <div className="p-6">
          {renderSectionContent()}
        </div>
      </main>
      {/* Modals */}
      {showFormulaInspector && (
        <FormulaInspector
          formulas={mockFormulas}
          rollups={mockRollups}
          onClose={() => setShowFormulaInspector(false)}
        />
      )}
      <DeploymentModal
        isOpen={showDeploymentModal}
        onClose={() => setShowDeploymentModal(false)}
        onDeploy={handleDeployConfirm}
        workspaceName={workspaceData?.title}
      />
    </div>
  );
};

export default WorkspacePreview;