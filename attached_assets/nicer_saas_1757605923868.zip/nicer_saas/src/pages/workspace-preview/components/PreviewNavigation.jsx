import React from 'react';
import Icon from '../../../components/AppIcon';

const PreviewNavigation = ({ 
  sections, 
  activeSection, 
  onSectionChange,
  density = 'spacious',
  onDensityChange 
}) => {
  const densityOptions = [
    { id: 'compact', name: 'Compact', icon: 'Minimize2' },
    { id: 'spacious', name: 'Spacious', icon: 'Maximize2' }
  ];

  return (
    <div className="bg-surface border-b border-border">
      <div className="px-6 py-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Section Tabs */}
          <div className="flex items-center space-x-1 overflow-x-auto">
            {sections?.map((section) => (
              <button
                key={section?.id}
                onClick={() => onSectionChange(section?.id)}
                className={`
                  flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap
                  transition-all duration-200 ease-spring
                  ${activeSection === section?.id
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }
                `}
              >
                <Icon name={section?.icon} size={16} />
                <span>{section?.name}</span>
                {section?.count && (
                  <span className={`
                    text-xs px-1.5 py-0.5 rounded
                    ${activeSection === section?.id
                      ? 'bg-primary-foreground/20'
                      : 'bg-muted'
                    }
                  `}>
                    {section?.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Density Control */}
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-foreground">Layout:</span>
            <div className="flex items-center bg-muted rounded-lg p-1">
              {densityOptions?.map((option) => (
                <button
                  key={option?.id}
                  onClick={() => onDensityChange(option?.id)}
                  className={`
                    flex items-center space-x-1 px-3 py-1.5 rounded-md text-xs font-medium
                    transition-all duration-200 ease-spring
                    ${density === option?.id
                      ? 'bg-surface text-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                    }
                  `}
                  title={option?.name}
                >
                  <Icon name={option?.icon} size={14} />
                  <span className="hidden sm:inline">{option?.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreviewNavigation;