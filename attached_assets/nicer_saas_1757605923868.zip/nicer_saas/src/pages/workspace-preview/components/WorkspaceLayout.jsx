import React from 'react';
import Icon from '../../../components/AppIcon';

const WorkspaceLayout = ({ workspace, theme, density }) => {
  const getThemeColors = (theme) => {
    const themes = {
      professional: { primary: '#2563EB', secondary: '#F1F5F9', accent: '#1E40AF' },
      pastel: { primary: '#EC4899', secondary: '#FDF2F8', accent: '#DB2777' },
      dark: { primary: '#1F2937', secondary: '#374151', accent: '#111827' },
      fun: { primary: '#F59E0B', secondary: '#FEF3C7', accent: '#D97706' },
      light: { primary: '#6B7280', secondary: '#F9FAFB', accent: '#4B5563' },
      cheerful: { primary: '#10B981', secondary: '#D1FAE5', accent: '#059669' },
      loving: { primary: '#EF4444', secondary: '#FEE2E2', accent: '#DC2626' },
      soft: { primary: '#8B5CF6', secondary: '#F3E8FF', accent: '#7C3AED' },
      rough: { primary: '#6B7280', secondary: '#F3F4F6', accent: '#374151' }
    };
    return themes?.[theme] || themes?.professional;
  };

  const themeColors = getThemeColors(theme);
  const isCompact = density === 'compact';

  const renderSection = (section) => (
    <div key={section?.id} className={`${isCompact ? 'mb-6' : 'mb-8'}`}>
      {/* Section Header */}
      <div className={`flex items-center space-x-3 ${isCompact ? 'mb-3' : 'mb-4'}`}>
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: themeColors?.primary }}
        >
          <Icon name={section?.icon} size={16} color="white" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-foreground">{section?.title}</h2>
          {section?.description && (
            <p className="text-sm text-muted-foreground">{section?.description}</p>
          )}
        </div>
      </div>

      {/* Section Content */}
      <div className="space-y-4">
        {section?.type === 'text' && (
          <div className="prose prose-sm max-w-none">
            <p className="text-foreground leading-relaxed">{section?.content}</p>
          </div>
        )}

        {section?.type === 'callout' && (
          <div
            className="rounded-lg p-4 border-l-4"
            style={{
              backgroundColor: themeColors?.secondary,
              borderLeftColor: themeColors?.primary
            }}
          >
            <div className="flex items-start space-x-3">
              <Icon name={section?.calloutIcon || 'Info'} size={20} style={{ color: themeColors?.primary }} />
              <div>
                <h4 className="font-medium text-foreground mb-1">{section?.calloutTitle}</h4>
                <p className="text-sm text-foreground">{section?.content}</p>
              </div>
            </div>
          </div>
        )}

        {section?.type === 'divider' && (
          <div className="flex items-center space-x-4">
            <div className="flex-1 h-px bg-border" />
            {section?.content && (
              <span className="text-sm text-muted-foreground">{section?.content}</span>
            )}
            <div className="flex-1 h-px bg-border" />
          </div>
        )}

        {section?.type === 'toggle' && (
          <details className="group">
            <summary className="flex items-center space-x-2 cursor-pointer text-foreground hover:text-primary">
              <Icon name="ChevronRight" size={16} className="group-open:rotate-90 transition-transform" />
              <span className="font-medium">{section?.title}</span>
            </summary>
            <div className="mt-2 ml-6 text-sm text-foreground">
              {section?.content}
            </div>
          </details>
        )}

        {section?.type === 'quote' && (
          <blockquote className="border-l-4 border-primary pl-4 italic text-foreground">
            "{section?.content}"
          </blockquote>
        )}

        {section?.type === 'code' && (
          <div className="bg-muted rounded-lg p-4">
            <pre className="text-sm font-mono text-foreground overflow-x-auto">
              <code>{section?.content}</code>
            </pre>
          </div>
        )}

        {section?.type === 'checklist' && (
          <div className="space-y-2">
            {section?.items?.map((item, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div className="w-4 h-4 border border-border rounded flex items-center justify-center">
                  {item?.checked && (
                    <Icon name="Check" size={12} className="text-success" />
                  )}
                </div>
                <span className={`text-sm ${item?.checked ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                  {item?.text}
                </span>
              </div>
            ))}
          </div>
        )}

        {section?.type === 'numbered-list' && (
          <ol className="list-decimal list-inside space-y-1">
            {section?.items?.map((item, index) => (
              <li key={index} className="text-sm text-foreground">{item}</li>
            ))}
          </ol>
        )}

        {section?.type === 'bullet-list' && (
          <ul className="list-disc list-inside space-y-1">
            {section?.items?.map((item, index) => (
              <li key={index} className="text-sm text-foreground">{item}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );

  return (
    <div className="bg-surface rounded-lg border border-border overflow-hidden">
      {/* Workspace Header */}
      <div
        className="p-6 border-b border-border"
        style={{ backgroundColor: themeColors?.secondary }}
      >
        <div className="flex items-center space-x-4">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center"
            style={{ backgroundColor: themeColors?.primary }}
          >
            <Icon name={workspace?.icon} size={24} color="white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{workspace?.title}</h1>
            <p className="text-muted-foreground">{workspace?.description}</p>
          </div>
        </div>
      </div>
      {/* Workspace Content */}
      <div className={`${isCompact ? 'p-4' : 'p-6'}`}>
        {workspace?.sections?.map(renderSection)}
      </div>
      {/* Workspace Footer */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center space-x-4">
            <span>Created with Nicer SaaS</span>
            <span>•</span>
            <span>{new Date()?.toLocaleDateString()}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Sparkles" size={14} />
            <span>AI Generated</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkspaceLayout;