import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';


const DatabasePreview = ({ database, theme, density }) => {
  const [activeView, setActiveView] = useState('table');

  const views = [
    { id: 'table', name: 'Table', icon: 'Table' },
    { id: 'board', name: 'Board', icon: 'Columns' },
    { id: 'calendar', name: 'Calendar', icon: 'Calendar' },
    { id: 'gallery', name: 'Gallery', icon: 'Grid' },
    { id: 'list', name: 'List', icon: 'List' },
    { id: 'timeline', name: 'Timeline', icon: 'Clock' }
  ];

  const getThemeColors = (theme) => {
    const themes = {
      professional: { primary: '#2563EB', secondary: '#F1F5F9' },
      pastel: { primary: '#EC4899', secondary: '#FDF2F8' },
      dark: { primary: '#1F2937', secondary: '#374151' },
      fun: { primary: '#F59E0B', secondary: '#FEF3C7' },
      light: { primary: '#6B7280', secondary: '#F9FAFB' },
      cheerful: { primary: '#10B981', secondary: '#D1FAE5' },
      loving: { primary: '#EF4444', secondary: '#FEE2E2' },
      soft: { primary: '#8B5CF6', secondary: '#F3E8FF' },
      rough: { primary: '#6B7280', secondary: '#F3F4F6' }
    };
    return themes?.[theme] || themes?.professional;
  };

  const themeColors = getThemeColors(theme);
  const isCompact = density === 'compact';

  const renderTableView = () => (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-border">
            {database?.properties?.map((property) => (
              <th
                key={property?.id}
                className={`text-left font-medium text-foreground ${
                  isCompact ? 'px-3 py-2' : 'px-4 py-3'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <Icon name={property?.icon} size={16} />
                  <span>{property?.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {property?.type}
                  </span>
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {database?.sampleData?.map((row, index) => (
            <tr key={index} className="border-b border-border hover:bg-muted/50">
              {database?.properties?.map((property) => (
                <td
                  key={property?.id}
                  className={`text-foreground ${
                    isCompact ? 'px-3 py-2' : 'px-4 py-3'
                  }`}
                >
                  {renderPropertyValue(row?.[property?.id], property?.type)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderBoardView = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {['To Do', 'In Progress', 'Review', 'Done']?.map((status) => (
        <div key={status} className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-medium text-foreground">{status}</h4>
            <span className="text-xs bg-muted px-2 py-1 rounded">
              {database?.sampleData?.filter(item => item?.status === status)?.length}
            </span>
          </div>
          <div className="space-y-2">
            {database?.sampleData?.filter(item => item?.status === status)?.slice(0, 3)?.map((item, index) => (
                <div
                  key={index}
                  className="bg-surface border border-border rounded-lg p-3 shadow-sm"
                >
                  <h5 className="font-medium text-foreground text-sm mb-1">
                    {item?.title || item?.name}
                  </h5>
                  <p className="text-xs text-muted-foreground">
                    {item?.description?.substring(0, 60)}...
                  </p>
                </div>
              ))}
          </div>
        </div>
      ))}
    </div>
  );

  const renderPropertyValue = (value, type) => {
    switch (type) {
      case 'status':
        return (
          <span
            className="px-2 py-1 rounded text-xs font-medium"
            style={{
              backgroundColor: themeColors?.secondary,
              color: themeColors?.primary
            }}
          >
            {value}
          </span>
        );
      case 'date':
        return <span className="text-sm">{value}</span>;
      case 'person':
        return (
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
              <Icon name="User" size={12} color="white" />
            </div>
            <span className="text-sm">{value}</span>
          </div>
        );
      case 'formula':
        return <span className="font-mono text-sm text-accent">{value}</span>;
      default:
        return <span className="text-sm">{value}</span>;
    }
  };

  return (
    <div className="bg-surface rounded-lg border border-border overflow-hidden">
      {/* Database Header */}
      <div className="p-4 border-b border-border">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: themeColors?.primary }}
            >
              <Icon name={database?.icon} size={16} color="white" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">{database?.name}</h3>
              <p className="text-sm text-muted-foreground">{database?.description}</p>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            {views?.map((view) => (
              <button
                key={view?.id}
                onClick={() => setActiveView(view?.id)}
                className={`
                  flex items-center space-x-1 px-3 py-1.5 rounded-md text-sm font-medium
                  transition-all duration-200 ease-spring
                  ${activeView === view?.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }
                `}
              >
                <Icon name={view?.icon} size={14} />
                <span className="hidden sm:inline">{view?.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
      {/* Database Content */}
      <div className={isCompact ? 'p-3' : 'p-4'}>
        {activeView === 'table' && renderTableView()}
        {activeView === 'board' && renderBoardView()}
        {activeView === 'calendar' && (
          <div className="text-center py-12">
            <Icon name="Calendar" size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Calendar view preview</p>
          </div>
        )}
        {activeView === 'gallery' && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {database?.sampleData?.slice(0, 8)?.map((item, index) => (
              <div key={index} className="bg-muted/30 rounded-lg p-3 text-center">
                <div className="w-full h-24 bg-muted rounded-lg mb-2 flex items-center justify-center">
                  <Icon name="Image" size={24} className="text-muted-foreground" />
                </div>
                <p className="text-sm font-medium text-foreground truncate">
                  {item?.title || item?.name}
                </p>
              </div>
            ))}
          </div>
        )}
        {(activeView === 'list' || activeView === 'timeline') && (
          <div className="text-center py-12">
            <Icon name={activeView === 'list' ? 'List' : 'Clock'} size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">{activeView === 'list' ? 'List' : 'Timeline'} view preview</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default DatabasePreview;