import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PreviewHeader = ({ 
  workspaceName, 
  theme, 
  onThemeChange, 
  onDeploy, 
  onModify, 
  onSave,
  isDeploying = false 
}) => {
  const themes = [
    { id: 'professional', name: 'Professional', color: '#2563EB' },
    { id: 'pastel', name: 'Pastel', color: '#EC4899' },
    { id: 'dark', name: 'Dark', color: '#1F2937' },
    { id: 'fun', name: 'Fun', color: '#F59E0B' },
    { id: 'light', name: 'Light', color: '#F3F4F6' },
    { id: 'cheerful', name: 'Cheerful', color: '#10B981' },
    { id: 'loving', name: 'Loving', color: '#EF4444' },
    { id: 'soft', name: 'Soft', color: '#8B5CF6' },
    { id: 'rough', name: 'Rough', color: '#6B7280' }
  ];

  return (
    <div className="bg-surface border-b border-border p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Workspace Info */}
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
            <Icon name="Eye" size={24} color="white" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">{workspaceName}</h1>
            <p className="text-sm text-muted-foreground">Preview your AI-generated workspace</p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Theme Selector */}
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-foreground">Theme:</span>
            <select
              value={theme}
              onChange={(e) => onThemeChange(e?.target?.value)}
              className="px-3 py-2 bg-input border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              {themes?.map((t) => (
                <option key={t?.id} value={t?.id}>
                  {t?.name}
                </option>
              ))}
            </select>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              iconName="Edit"
              iconPosition="left"
              onClick={onModify}
            >
              Modify
            </Button>
            <Button
              variant="outline"
              size="sm"
              iconName="Save"
              iconPosition="left"
              onClick={onSave}
            >
              Save
            </Button>
            <Button
              variant="default"
              size="sm"
              iconName="Rocket"
              iconPosition="left"
              onClick={onDeploy}
              loading={isDeploying}
              disabled={isDeploying}
            >
              {isDeploying ? 'Deploying...' : 'Deploy to Notion'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreviewHeader;