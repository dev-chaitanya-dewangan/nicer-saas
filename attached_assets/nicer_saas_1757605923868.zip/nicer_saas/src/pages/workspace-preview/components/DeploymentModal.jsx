import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DeploymentModal = ({ isOpen, onClose, onDeploy, workspaceName }) => {
  const [deploymentStep, setDeploymentStep] = useState('confirm');
  const [progress, setProgress] = useState(0);
  const [deploymentSteps, setDeploymentSteps] = useState([]);

  const steps = [
    { id: 'auth', name: 'Authenticating with Notion', icon: 'Shield' },
    { id: 'create', name: 'Creating workspace structure', icon: 'FolderPlus' },
    { id: 'databases', name: 'Setting up databases', icon: 'Database' },
    { id: 'properties', name: 'Configuring properties', icon: 'Settings' },
    { id: 'formulas', name: 'Applying formulas and rollups', icon: 'Calculator' },
    { id: 'sample', name: 'Adding sample data', icon: 'FileText' },
    { id: 'complete', name: 'Deployment complete', icon: 'CheckCircle' }
  ];

  useEffect(() => {
    if (deploymentStep === 'deploying') {
      let currentStep = 0;
      const interval = setInterval(() => {
        if (currentStep < steps?.length) {
          setDeploymentSteps(prev => [...prev, steps?.[currentStep]]);
          setProgress(((currentStep + 1) / steps?.length) * 100);
          currentStep++;
        } else {
          clearInterval(interval);
          setTimeout(() => {
            setDeploymentStep('success');
          }, 1000);
        }
      }, 1500);

      return () => clearInterval(interval);
    }
  }, [deploymentStep]);

  const handleDeploy = () => {
    setDeploymentStep('deploying');
    setDeploymentSteps([]);
    setProgress(0);
    onDeploy();
  };

  const renderConfirmStep = () => (
    <div className="p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Rocket" size={32} color="white" />
        </div>
        <h3 className="text-xl font-semibold text-foreground mb-2">Deploy to Notion</h3>
        <p className="text-muted-foreground">
          Ready to deploy "{workspaceName}" to your Notion workspace?
        </p>
      </div>

      <div className="bg-muted/50 rounded-lg p-4 mb-6">
        <h4 className="font-medium text-foreground mb-3">What will be created:</h4>
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span>Complete workspace structure with hierarchical layout</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span>3 databases with configured properties and relationships</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span>Advanced formulas and rollup calculations</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span>Sample data for immediate productivity</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span>Professional theme and visual styling</span>
          </div>
        </div>
      </div>

      <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 mb-6">
        <div className="flex items-start space-x-2">
          <Icon name="AlertTriangle" size={16} className="text-warning mt-0.5" />
          <div>
            <p className="text-sm font-medium text-warning mb-1">Important Note</p>
            <p className="text-sm text-foreground">
              This will create a new workspace in your connected Notion account. 
              Make sure you have the necessary permissions to create pages and databases.
            </p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button variant="default" iconName="Rocket" iconPosition="left" onClick={handleDeploy}>
          Deploy Workspace
        </Button>
      </div>
    </div>
  );

  const renderDeployingStep = () => (
    <div className="p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
          <Icon name="Loader" size={32} color="white" className="animate-spin" />
        </div>
        <h3 className="text-xl font-semibold text-foreground mb-2">Deploying Workspace</h3>
        <p className="text-muted-foreground">
          Creating your workspace in Notion...
        </p>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">Progress</span>
          <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full transition-all duration-500 ease-spring"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Deployment Steps */}
      <div className="space-y-3">
        {deploymentSteps?.map((step, index) => (
          <div key={step?.id} className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-success rounded-full flex items-center justify-center">
              <Icon name={step?.icon} size={16} color="white" />
            </div>
            <span className="text-sm text-foreground">{step?.name}</span>
            <Icon name="CheckCircle" size={16} className="text-success" />
          </div>
        ))}
        
        {deploymentSteps?.length < steps?.length && (
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
              <Icon name="Loader" size={16} className="animate-spin" />
            </div>
            <span className="text-sm text-muted-foreground">
              {steps?.[deploymentSteps?.length]?.name}
            </span>
          </div>
        )}
      </div>
    </div>
  );

  const renderSuccessStep = () => (
    <div className="p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="CheckCircle" size={32} color="white" />
        </div>
        <h3 className="text-xl font-semibold text-foreground mb-2">Deployment Successful!</h3>
        <p className="text-muted-foreground">
          Your workspace has been created in Notion and is ready to use.
        </p>
      </div>

      <div className="bg-success/10 border border-success/20 rounded-lg p-4 mb-6">
        <div className="flex items-center space-x-2 mb-2">
          <Icon name="ExternalLink" size={16} className="text-success" />
          <span className="font-medium text-success">Workspace Created</span>
        </div>
        <p className="text-sm text-foreground mb-3">
          "{workspaceName}" is now available in your Notion workspace.
        </p>
        <Button variant="outline" size="sm" iconName="ExternalLink" iconPosition="left">
          Open in Notion
        </Button>
      </div>

      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onClose}>
          Close
        </Button>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" iconName="Share">
            Share
          </Button>
          <Button variant="default" iconName="Plus" iconPosition="left">
            Create Another
          </Button>
        </div>
      </div>
    </div>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-surface border border-border rounded-xl shadow-floating w-full max-w-md">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-foreground">
              {deploymentStep === 'confirm' && 'Deploy Workspace'}
              {deploymentStep === 'deploying' && 'Deploying...'}
              {deploymentStep === 'success' && 'Success!'}
            </h2>
            {deploymentStep !== 'deploying' && (
              <Button variant="ghost" size="sm" iconName="X" onClick={onClose} />
            )}
          </div>
        </div>

        {/* Content */}
        {deploymentStep === 'confirm' && renderConfirmStep()}
        {deploymentStep === 'deploying' && renderDeployingStep()}
        {deploymentStep === 'success' && renderSuccessStep()}
      </div>
    </div>
  );
};

export default DeploymentModal;