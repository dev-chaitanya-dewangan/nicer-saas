import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FormulaInspector = ({ formulas, rollups, onClose }) => {
  const [activeTab, setActiveTab] = useState('formulas');

  const tabs = [
    { id: 'formulas', name: 'Formulas', icon: 'Calculator', count: formulas?.length },
    { id: 'rollups', name: 'Rollups', icon: 'BarChart3', count: rollups?.length }
  ];

  const renderFormulaItem = (formula) => (
    <div key={formula?.id} className="bg-surface border border-border rounded-lg p-4">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon name="Calculator" size={16} className="text-primary" />
          <h4 className="font-medium text-foreground">{formula?.name}</h4>
        </div>
        <span className="text-xs bg-muted px-2 py-1 rounded">{formula?.type}</span>
      </div>
      
      <p className="text-sm text-muted-foreground mb-3">{formula?.description}</p>
      
      <div className="bg-muted/50 rounded-lg p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Formula Expression
          </span>
          <Button variant="ghost" size="xs" iconName="Copy">
            Copy
          </Button>
        </div>
        <code className="text-sm font-mono text-foreground block">
          {formula?.expression}
        </code>
      </div>
      
      {formula?.example && (
        <div className="mt-3 p-3 bg-success/10 border border-success/20 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Icon name="Lightbulb" size={14} className="text-success" />
            <span className="text-xs font-medium text-success">Example Output</span>
          </div>
          <p className="text-sm text-foreground">{formula?.example}</p>
        </div>
      )}
    </div>
  );

  const renderRollupItem = (rollup) => (
    <div key={rollup?.id} className="bg-surface border border-border rounded-lg p-4">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon name="BarChart3" size={16} className="text-accent" />
          <h4 className="font-medium text-foreground">{rollup?.name}</h4>
        </div>
        <span className="text-xs bg-muted px-2 py-1 rounded">{rollup?.function}</span>
      </div>
      
      <p className="text-sm text-muted-foreground mb-3">{rollup?.description}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="bg-muted/50 rounded-lg p-3">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider block mb-1">
            Source Database
          </span>
          <div className="flex items-center space-x-2">
            <Icon name="Database" size={14} />
            <span className="text-sm text-foreground">{rollup?.sourceDatabase}</span>
          </div>
        </div>
        
        <div className="bg-muted/50 rounded-lg p-3">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider block mb-1">
            Target Property
          </span>
          <div className="flex items-center space-x-2">
            <Icon name="Target" size={14} />
            <span className="text-sm text-foreground">{rollup?.targetProperty}</span>
          </div>
        </div>
      </div>
      
      {rollup?.example && (
        <div className="mt-3 p-3 bg-accent/10 border border-accent/20 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Icon name="TrendingUp" size={14} className="text-accent" />
            <span className="text-xs font-medium text-accent">Sample Result</span>
          </div>
          <p className="text-sm text-foreground">{rollup?.example}</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-surface border border-border rounded-xl shadow-floating w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="Code" size={20} color="white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Formula Inspector</h2>
                <p className="text-sm text-muted-foreground">
                  Review generated formulas and rollup configurations
                </p>
              </div>
            </div>
            <Button variant="ghost" size="sm" iconName="X" onClick={onClose} />
          </div>
        </div>

        {/* Tabs */}
        <div className="px-6 pt-4">
          <div className="flex items-center space-x-1">
            {tabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`
                  flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium
                  transition-all duration-200 ease-spring
                  ${activeTab === tab?.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }
                `}
              >
                <Icon name={tab?.icon} size={16} />
                <span>{tab?.name}</span>
                <span className={`
                  text-xs px-1.5 py-0.5 rounded
                  ${activeTab === tab?.id
                    ? 'bg-primary-foreground/20'
                    : 'bg-muted'
                  }
                `}>
                  {tab?.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-4">
            {activeTab === 'formulas' && formulas?.map(renderFormulaItem)}
            {activeTab === 'rollups' && rollups?.map(renderRollupItem)}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              {activeTab === 'formulas' 
                ? `${formulas?.length} formulas configured`
                : `${rollups?.length} rollups configured`
              }
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" iconName="Download">
                Export Config
              </Button>
              <Button variant="default" size="sm" onClick={onClose}>
                Done
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormulaInspector;