import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const TemplateLibrary = ({ onSelectTemplate }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedUseCase, setSelectedUseCase] = useState('all');

  const categories = [
    { id: 'all', label: 'All Templates', icon: 'Grid3x3' },
    { id: 'business', label: 'Business', icon: 'Briefcase' },
    { id: 'creative', label: 'Creative', icon: 'Palette' },
    { id: 'personal', label: 'Personal', icon: 'User' },
    { id: 'education', label: 'Education', icon: 'GraduationCap' }
  ];

  const useCases = [
    { id: 'all', label: 'All Use Cases' },
    { id: 'project-management', label: 'Project Management' },
    { id: 'crm', label: 'CRM & Sales' },
    { id: 'content', label: 'Content Planning' },
    { id: 'knowledge', label: 'Knowledge Base' },
    { id: 'finance', label: 'Finance & Budget' }
  ];

  const templates = [
    {
      id: 'crm-advanced',
      name: 'Advanced CRM System',
      description: 'Complete customer relationship management with lead tracking, sales pipeline, and analytics',
      category: 'business',
      useCase: 'crm',
      difficulty: 'Medium',
      timeEstimate: '8-12 min',
      thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop',
      features: ['Lead Management', 'Sales Pipeline', 'Contact Database', 'Analytics Dashboard'],
      databases: 5,
      views: 15,
      popular: true,
      new: false
    },
    {
      id: 'project-kanban',
      name: 'Project Kanban Board',
      description: 'Agile project management with task boards, sprints, and team collaboration',
      category: 'business',
      useCase: 'project-management',
      difficulty: 'Easy',
      timeEstimate: '3-5 min',
      thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=300&fit=crop',
      features: ['Kanban Boards', 'Sprint Planning', 'Task Management', 'Team Collaboration'],
      databases: 3,
      views: 8,
      popular: true,
      new: false
    },
    {
      id: 'content-calendar',
      name: 'Social Media Calendar',
      description: 'Content planning and scheduling for social media platforms',
      category: 'creative',
      useCase: 'content',
      difficulty: 'Easy',
      timeEstimate: '2-4 min',
      thumbnail: 'https://images.unsplash.com/photo-1611262588024-d12430b98920?w=400&h=300&fit=crop',
      features: ['Content Calendar', 'Platform Management', 'Publishing Schedule', 'Analytics'],
      databases: 2,
      views: 6,
      popular: false,
      new: true
    },
    {
      id: 'knowledge-base',
      name: 'Team Knowledge Hub',
      description: 'Centralized documentation and knowledge sharing system',
      category: 'business',
      useCase: 'knowledge',
      difficulty: 'Medium',
      timeEstimate: '6-10 min',
      thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop',
      features: ['Document Library', 'Search System', 'Categories', 'Version Control'],
      databases: 2,
      views: 5,
      popular: false,
      new: false
    },
    {
      id: 'habit-tracker',
      name: 'Personal Habit Tracker',
      description: 'Track daily habits and build positive routines with progress analytics',
      category: 'personal',
      useCase: 'all',
      difficulty: 'Easy',
      timeEstimate: '2-3 min',
      thumbnail: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=400&h=300&fit=crop',
      features: ['Habit Tracking', 'Progress Charts', 'Streak Counter', 'Goal Setting'],
      databases: 2,
      views: 4,
      popular: false,
      new: true
    },
    {
      id: 'finance-tracker',
      name: 'Personal Finance Manager',
      description: 'Complete financial tracking with budgets, expenses, and investment monitoring',
      category: 'personal',
      useCase: 'finance',
      difficulty: 'Hard',
      timeEstimate: '10-15 min',
      thumbnail: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=300&fit=crop',
      features: ['Budget Tracking', 'Expense Categories', 'Investment Portfolio', 'Financial Goals'],
      databases: 4,
      views: 12,
      popular: true,
      new: false
    }
  ];

  const filteredTemplates = templates?.filter(template => {
    const categoryMatch = selectedCategory === 'all' || template?.category === selectedCategory;
    const useCaseMatch = selectedUseCase === 'all' || template?.useCase === selectedUseCase;
    return categoryMatch && useCaseMatch;
  });

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy': return 'text-success bg-success/10 border-success/20';
      case 'Medium': return 'text-warning bg-warning/10 border-warning/20';
      case 'Hard': return 'text-error bg-error/10 border-error/20';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  const handleTemplateSelect = (template) => {
    onSelectTemplate(template);
  };

  return (
    <div className="bg-card border border-border rounded-xl p-6 shadow-card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
            <Icon name="Layout" size={18} className="text-accent" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Template Library</h2>
            <p className="text-sm text-muted-foreground">Pre-built workspaces ready to customize</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" iconName="ExternalLink">
          Browse All
        </Button>
      </div>
      {/* Category Filters */}
      <div className="mb-4">
        <div className="flex items-center space-x-2 overflow-x-auto pb-2">
          {categories?.map((category) => (
            <button
              key={category?.id}
              onClick={() => setSelectedCategory(category?.id)}
              className={`
                flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap
                transition-all duration-200 border
                ${selectedCategory === category?.id
                  ? 'bg-primary text-white border-primary' :'bg-card text-muted-foreground border-border hover:border-primary/30 hover:text-foreground'
                }
              `}
            >
              <Icon name={category?.icon} size={14} />
              <span>{category?.label}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Use Case Filter */}
      <div className="mb-6">
        <select
          value={selectedUseCase}
          onChange={(e) => setSelectedUseCase(e?.target?.value)}
          className="w-full md:w-auto px-3 py-2 border border-border rounded-lg bg-input text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
        >
          {useCases?.map((useCase) => (
            <option key={useCase?.id} value={useCase?.id}>
              {useCase?.label}
            </option>
          ))}
        </select>
      </div>
      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
        {filteredTemplates?.map((template) => (
          <div
            key={template?.id}
            className="border border-border rounded-lg overflow-hidden hover:shadow-soft transition-all duration-200 hover:border-primary/30 bg-card"
          >
            {/* Template Thumbnail */}
            <div className="relative h-32 bg-muted overflow-hidden">
              <Image
                src={template?.thumbnail}
                alt={template?.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2 flex items-center space-x-1">
                {template?.popular && (
                  <span className="px-2 py-1 bg-primary text-white text-xs rounded-full font-medium">
                    Popular
                  </span>
                )}
                {template?.new && (
                  <span className="px-2 py-1 bg-success text-white text-xs rounded-full font-medium">
                    New
                  </span>
                )}
              </div>
              <div className="absolute top-2 right-2">
                <span className={`px-2 py-1 text-xs rounded-full border font-medium ${getDifficultyColor(template?.difficulty)}`}>
                  {template?.difficulty}
                </span>
              </div>
            </div>

            {/* Template Content */}
            <div className="p-4">
              <div className="mb-3">
                <h3 className="font-semibold text-foreground mb-1">{template?.name}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2">{template?.description}</p>
              </div>

              {/* Features */}
              <div className="mb-3">
                <div className="flex flex-wrap gap-1">
                  {template?.features?.slice(0, 3)?.map((feature, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-muted text-xs text-muted-foreground rounded"
                    >
                      {feature}
                    </span>
                  ))}
                  {template?.features?.length > 3 && (
                    <span className="px-2 py-1 bg-muted text-xs text-muted-foreground rounded">
                      +{template?.features?.length - 3} more
                    </span>
                  )}
                </div>
              </div>

              {/* Stats */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Icon name="Database" size={12} />
                    <span>{template?.databases} DB</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Layout" size={12} />
                    <span>{template?.views} views</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={12} />
                    <span>{template?.timeEstimate}</span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <Button
                variant="default"
                size="sm"
                iconName="Plus"
                iconPosition="left"
                onClick={() => handleTemplateSelect(template)}
                className="w-full"
              >
                Use Template
              </Button>
            </div>
          </div>
        ))}
      </div>
      {filteredTemplates?.length === 0 && (
        <div className="text-center py-8">
          <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No templates found</h3>
          <p className="text-muted-foreground mb-4">
            Try adjusting your filters or browse all templates
          </p>
          <Button
            variant="outline"
            onClick={() => {
              setSelectedCategory('all');
              setSelectedUseCase('all');
            }}
          >
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
};

export default TemplateLibrary;