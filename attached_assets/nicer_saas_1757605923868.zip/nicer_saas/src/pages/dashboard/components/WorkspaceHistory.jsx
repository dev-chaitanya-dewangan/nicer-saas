import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const WorkspaceHistory = ({ onRegenerate, onPreview, onDeploy }) => {
  const [selectedWorkspace, setSelectedWorkspace] = useState(null);

  const workspaceHistory = [
    {
      id: 'ws-001',
      name: 'Project Management Hub',
      description: 'Complete project tracking with task boards, timelines, and team collaboration',
      thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=300&fit=crop',
      createdAt: new Date('2025-01-10T14:30:00'),
      status: 'deployed',
      theme: 'professional',
      databases: 4,
      views: 12,
      prompt: 'Create a project management system with task boards and team collaboration'
    },
    {
      id: 'ws-002',
      name: 'CRM System',
      description: 'Customer relationship management with lead tracking and sales pipeline',
      thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop',
      createdAt: new Date('2025-01-09T09:15:00'),
      status: 'preview',
      theme: 'pastel',
      databases: 6,
      views: 18,
      prompt: 'Build a comprehensive CRM system for managing leads and customers'
    },
    {
      id: 'ws-003',
      name: 'Content Calendar',
      description: 'Social media planning and content scheduling workspace',
      thumbnail: 'https://images.unsplash.com/photo-1611262588024-d12430b98920?w=400&h=300&fit=crop',
      createdAt: new Date('2025-01-08T16:45:00'),
      status: 'draft',
      theme: 'cheerful',
      databases: 3,
      views: 8,
      prompt: 'Design a content calendar for social media planning and scheduling'
    },
    {
      id: 'ws-004',
      name: 'Knowledge Base',
      description: 'Team documentation and knowledge sharing system',
      thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop',
      createdAt: new Date('2025-01-07T11:20:00'),
      status: 'deployed',
      theme: 'dark',
      databases: 2,
      views: 6,
      prompt: 'Set up a knowledge base for team documentation and resources'
    },
    {
      id: 'ws-005',
      name: 'Finance Tracker',
      description: 'Personal finance management with budget tracking and expense analysis',
      thumbnail: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=300&fit=crop',
      createdAt: new Date('2025-01-06T13:10:00'),
      status: 'preview',
      theme: 'professional',
      databases: 5,
      views: 15,
      prompt: 'Create a comprehensive finance tracker with budget and expense management'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'deployed': return 'text-success bg-success/10 border-success/20';
      case 'preview': return 'text-warning bg-warning/10 border-warning/20';
      case 'draft': return 'text-muted-foreground bg-muted border-border';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'deployed': return 'CheckCircle';
      case 'preview': return 'Eye';
      case 'draft': return 'FileText';
      default: return 'FileText';
    }
  };

  const formatDate = (date) => {
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 48) return 'Yesterday';
    return date?.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const handleWorkspaceAction = (workspace, action) => {
    switch (action) {
      case 'regenerate':
        onRegenerate(workspace?.prompt, workspace?.theme);
        break;
      case 'preview':
        onPreview(workspace?.id);
        break;
      case 'deploy':
        onDeploy(workspace?.id);
        break;
      default:
        break;
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl p-6 shadow-card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
            <Icon name="History" size={18} className="text-accent" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Workspace History</h2>
            <p className="text-sm text-muted-foreground">Your recently created workspaces</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
      </div>
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {workspaceHistory?.map((workspace) => (
          <div
            key={workspace?.id}
            className={`
              p-4 rounded-lg border transition-all duration-200 hover:shadow-soft cursor-pointer
              ${selectedWorkspace === workspace?.id
                ? 'border-primary bg-primary/5' :'border-border bg-card hover:border-primary/30'
              }
            `}
            onClick={() => setSelectedWorkspace(workspace?.id === selectedWorkspace ? null : workspace?.id)}
          >
            <div className="flex space-x-4">
              {/* Thumbnail */}
              <div className="w-16 h-12 rounded-md overflow-hidden flex-shrink-0 bg-muted">
                <Image
                  src={workspace?.thumbnail}
                  alt={workspace?.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground truncate">{workspace?.name}</h3>
                    <p className="text-sm text-muted-foreground truncate">{workspace?.description}</p>
                  </div>
                  <div className={`ml-3 px-2 py-1 rounded-full border text-xs font-medium ${getStatusColor(workspace?.status)}`}>
                    <div className="flex items-center space-x-1">
                      <Icon name={getStatusIcon(workspace?.status)} size={12} />
                      <span className="capitalize">{workspace?.status}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Icon name="Database" size={12} />
                      <span>{workspace?.databases} databases</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name="Layout" size={12} />
                      <span>{workspace?.views} views</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name="Clock" size={12} />
                      <span>{formatDate(workspace?.createdAt)}</span>
                    </div>
                  </div>
                </div>

                {/* Expanded Actions */}
                {selectedWorkspace === workspace?.id && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">
                        <span className="font-medium">Theme:</span> {workspace?.theme} • 
                        <span className="font-medium"> Prompt:</span> "{workspace?.prompt?.substring(0, 50)}..."
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="xs"
                          iconName="RotateCcw"
                          onClick={(e) => {
                            e?.stopPropagation();
                            handleWorkspaceAction(workspace, 'regenerate');
                          }}
                        >
                          Regenerate
                        </Button>
                        <Button
                          variant="ghost"
                          size="xs"
                          iconName="Eye"
                          onClick={(e) => {
                            e?.stopPropagation();
                            handleWorkspaceAction(workspace, 'preview');
                          }}
                        >
                          Preview
                        </Button>
                        {workspace?.status !== 'deployed' && (
                          <Button
                            variant="default"
                            size="xs"
                            iconName="Upload"
                            onClick={(e) => {
                              e?.stopPropagation();
                              handleWorkspaceAction(workspace, 'deploy');
                            }}
                          >
                            Deploy
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* View All Button */}
      <div className="mt-4 pt-4 border-t border-border">
        <Button variant="ghost" size="sm" iconName="ArrowRight" iconPosition="right" className="w-full">
          View All Workspaces
        </Button>
      </div>
    </div>
  );
};

export default WorkspaceHistory;