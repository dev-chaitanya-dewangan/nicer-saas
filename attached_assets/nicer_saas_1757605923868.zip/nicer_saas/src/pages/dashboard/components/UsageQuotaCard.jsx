import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const UsageQuotaCard = ({ onUpgrade }) => {
  const currentPlan = {
    name: 'Pro Plan',
    workspacesUsed: 12,
    workspacesLimit: 25,
    deploymentsUsed: 8,
    deploymentsLimit: 15,
    aiRequestsUsed: 145,
    aiRequestsLimit: 200,
    billingCycle: 'monthly',
    nextBilling: new Date('2025-02-11T00:00:00'),
    features: ['Unlimited previews', 'Custom themes', 'Priority support', 'CSV export']
  };

  const getUsagePercentage = (used, limit) => {
    return Math.min((used / limit) * 100, 100);
  };

  const getUsageColor = (percentage) => {
    if (percentage >= 90) return 'bg-error';
    if (percentage >= 75) return 'bg-warning';
    return 'bg-primary';
  };

  const formatDate = (date) => {
    return date?.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const usageItems = [
    {
      label: 'Workspaces Created',
      used: currentPlan?.workspacesUsed,
      limit: currentPlan?.workspacesLimit,
      icon: 'Layout'
    },
    {
      label: 'Deployments',
      used: currentPlan?.deploymentsUsed,
      limit: currentPlan?.deploymentsLimit,
      icon: 'Upload'
    },
    {
      label: 'AI Requests',
      used: currentPlan?.aiRequestsUsed,
      limit: currentPlan?.aiRequestsLimit,
      icon: 'Zap'
    }
  ];

  const isNearLimit = (used, limit) => {
    return (used / limit) >= 0.8;
  };

  return (
    <div className="bg-card border border-border rounded-xl p-6 shadow-card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
            <Icon name="Crown" size={18} className="text-success" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">{currentPlan?.name}</h2>
            <p className="text-sm text-muted-foreground">
              Renews {formatDate(currentPlan?.nextBilling)}
            </p>
          </div>
        </div>
        <Button variant="outline" size="sm" iconName="Settings">
          Manage
        </Button>
      </div>
      {/* Usage Metrics */}
      <div className="space-y-4 mb-6">
        {usageItems?.map((item) => {
          const percentage = getUsagePercentage(item?.used, item?.limit);
          const isWarning = isNearLimit(item?.used, item?.limit);
          
          return (
            <div key={item?.label} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Icon name={item?.icon} size={16} className="text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">{item?.label}</span>
                  {isWarning && (
                    <Icon name="AlertTriangle" size={14} className="text-warning" />
                  )}
                </div>
                <span className="text-sm text-muted-foreground">
                  {item?.used} / {item?.limit}
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all duration-300 ${getUsageColor(percentage)}`}
                  style={{ width: `${percentage}%` }}
                />
              </div>
              {isWarning && (
                <p className="text-xs text-warning">
                  You're approaching your {item?.label?.toLowerCase()} limit
                </p>
              )}
            </div>
          );
        })}
      </div>
      {/* Plan Features */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-foreground mb-3">Plan Features</h3>
        <div className="grid grid-cols-2 gap-2">
          {currentPlan?.features?.map((feature, index) => (
            <div key={index} className="flex items-center space-x-2">
              <Icon name="Check" size={14} className="text-success" />
              <span className="text-xs text-muted-foreground">{feature}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Upgrade Prompt */}
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
            <Icon name="Sparkles" size={16} color="white" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-semibold text-foreground mb-1">
              Upgrade to Enterprise
            </h3>
            <p className="text-xs text-muted-foreground mb-3">
              Get unlimited workspaces, custom branding, SSO, and dedicated support.
            </p>
            <div className="flex items-center space-x-2">
              <Button
                variant="default"
                size="xs"
                iconName="ArrowUp"
                iconPosition="left"
                onClick={onUpgrade}
              >
                Upgrade Now
              </Button>
              <Button variant="ghost" size="xs">
                Compare Plans
              </Button>
            </div>
          </div>
        </div>
      </div>
      {/* Quick Stats */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-foreground">
              {currentPlan?.workspacesUsed}
            </div>
            <div className="text-xs text-muted-foreground">This Month</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-foreground">
              {currentPlan?.deploymentsUsed}
            </div>
            <div className="text-xs text-muted-foreground">Deployed</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-foreground">
              {Math.round(((currentPlan?.workspacesLimit - currentPlan?.workspacesUsed) / currentPlan?.workspacesLimit) * 100)}%
            </div>
            <div className="text-xs text-muted-foreground">Remaining</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UsageQuotaCard;