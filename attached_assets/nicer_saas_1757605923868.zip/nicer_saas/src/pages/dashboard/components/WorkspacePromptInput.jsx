import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const WorkspacePromptInput = ({ onGenerate, isGenerating }) => {
  const [prompt, setPrompt] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const templateSuggestions = [
    { id: 'crm', label: 'CRM System', icon: 'Users', difficulty: 'Medium', time: '5-10 min' },
    { id: 'project', label: 'Project Management', icon: 'Kanban', difficulty: 'Easy', time: '3-5 min' },
    { id: 'content', label: 'Content Calendar', icon: 'Calendar', difficulty: 'Easy', time: '2-4 min' },
    { id: 'knowledge', label: 'Knowledge Base', icon: 'BookOpen', difficulty: 'Medium', time: '8-12 min' },
    { id: 'habit', label: 'Habit Tracker', icon: 'Target', difficulty: 'Easy', time: '2-3 min' },
    { id: 'finance', label: 'Finance Tracker', icon: 'DollarSign', difficulty: 'Hard', time: '10-15 min' }
  ];

  const quickPrompts = [
    "Create a comprehensive CRM system for managing leads and customers",
    "Build a project management workspace with task boards and timelines",
    "Design a content calendar for social media planning",
    "Set up a knowledge base for team documentation",
    "Create a personal habit tracker with progress analytics"
  ];

  const handleTemplateSelect = (template) => {
    setSelectedTemplate(template?.id === selectedTemplate ? null : template?.id);
    if (template?.id !== selectedTemplate) {
      setPrompt(`Create a ${template?.label?.toLowerCase()} workspace with all essential features and databases`);
    } else {
      setPrompt('');
    }
  };

  const handleQuickPrompt = (promptText) => {
    setPrompt(promptText);
    setSelectedTemplate(null);
  };

  const handleGenerate = () => {
    if (prompt?.trim()) {
      onGenerate(prompt, selectedTemplate);
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Easy': return 'text-success bg-success/10';
      case 'Medium': return 'text-warning bg-warning/10';
      case 'Hard': return 'text-error bg-error/10';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl p-6 shadow-card">
      <div className="mb-6">
        <div className="flex items-center space-x-3 mb-2">
          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Wand2" size={18} className="text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">Generate Your Workspace</h2>
        </div>
        <p className="text-muted-foreground">
          Describe your ideal Notion workspace in natural language, and our AI will create it for you.
        </p>
      </div>
      {/* Main Prompt Input */}
      <div className="mb-6">
        <div className="relative">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e?.target?.value)}
            placeholder="Describe your workspace needs... e.g., 'Create a project management system with task boards, team collaboration, and progress tracking'"
            className="w-full h-32 p-4 border border-border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors text-foreground bg-input placeholder:text-muted-foreground"
            disabled={isGenerating}
          />
          <div className="absolute bottom-3 right-3 flex items-center space-x-2">
            <span className="text-xs text-muted-foreground">
              {prompt?.length}/500
            </span>
            <Button
              variant="default"
              size="sm"
              iconName="Sparkles"
              iconPosition="left"
              onClick={handleGenerate}
              disabled={!prompt?.trim() || isGenerating}
              loading={isGenerating}
            >
              {isGenerating ? 'Generating...' : 'Generate'}
            </Button>
          </div>
        </div>
      </div>
      {/* Template Suggestions */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-foreground mb-3">Popular Templates</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {templateSuggestions?.map((template) => (
            <button
              key={template?.id}
              onClick={() => handleTemplateSelect(template)}
              className={`
                p-3 rounded-lg border transition-all duration-200 text-left hover:shadow-soft
                ${selectedTemplate === template?.id
                  ? 'border-primary bg-primary/5 shadow-soft'
                  : 'border-border bg-card hover:border-primary/30'
                }
              `}
              disabled={isGenerating}
            >
              <div className="flex items-center space-x-2 mb-2">
                <Icon name={template?.icon} size={16} className="text-primary" />
                <span className="text-sm font-medium text-foreground">{template?.label}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className={`text-xs px-2 py-1 rounded-full ${getDifficultyColor(template?.difficulty)}`}>
                  {template?.difficulty}
                </span>
                <span className="text-xs text-muted-foreground">{template?.time}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
      {/* Quick Prompts */}
      <div>
        <h3 className="text-sm font-medium text-foreground mb-3">Quick Prompts</h3>
        <div className="space-y-2">
          {quickPrompts?.map((promptText, index) => (
            <button
              key={index}
              onClick={() => handleQuickPrompt(promptText)}
              className="w-full text-left p-3 rounded-lg border border-border bg-card hover:border-primary/30 hover:bg-primary/5 transition-all duration-200 text-sm text-muted-foreground hover:text-foreground"
              disabled={isGenerating}
            >
              <div className="flex items-center space-x-2">
                <Icon name="MessageSquare" size={14} className="text-primary flex-shrink-0" />
                <span className="truncate">{promptText}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WorkspacePromptInput;