import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActions = ({ onNavigate }) => {
  const quickActions = [
    {
      id: 'generate',
      title: 'Generate Workspace',
      description: 'Create a new workspace with AI',
      icon: 'Wand2',
      color: 'primary',
      route: '/workspace-generator',
      shortcut: 'Ctrl+N'
    },
    {
      id: 'preview',
      title: 'Preview & Deploy',
      description: 'Review and deploy workspaces',
      icon: 'Eye',
      color: 'accent',
      route: '/workspace-preview',
      shortcut: 'Ctrl+P'
    },
    {
      id: 'templates',
      title: 'Browse Templates',
      description: 'Explore pre-built solutions',
      icon: 'Layout',
      color: 'success',
      route: '/templates',
      shortcut: 'Ctrl+T'
    },
    {
      id: 'notion',
      title: 'Connect Notion',
      description: 'Link your Notion workspace',
      icon: 'Link',
      color: 'warning',
      route: '/settings/integrations',
      shortcut: null
    }
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'workspace_created',
      title: 'Project Management Hub created',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      icon: 'Plus',
      color: 'success'
    },
    {
      id: 2,
      type: 'workspace_deployed',
      title: 'CRM System deployed to Notion',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
      icon: 'Upload',
      color: 'primary'
    },
    {
      id: 3,
      type: 'template_used',
      title: 'Content Calendar template used',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      icon: 'Layout',
      color: 'accent'
    },
    {
      id: 4,
      type: 'workspace_modified',
      title: 'Finance Tracker updated',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      icon: 'Edit',
      color: 'warning'
    }
  ];

  const getColorClasses = (color) => {
    const colorMap = {
      primary: 'bg-primary/10 text-primary border-primary/20',
      accent: 'bg-accent/10 text-accent border-accent/20',
      success: 'bg-success/10 text-success border-success/20',
      warning: 'bg-warning/10 text-warning border-warning/20',
      error: 'bg-error/10 text-error border-error/20'
    };
    return colorMap?.[color] || colorMap?.primary;
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diffInHours = Math.floor((now - timestamp) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 48) return 'Yesterday';
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  const handleActionClick = (action) => {
    if (onNavigate) {
      onNavigate(action?.route);
    } else {
      window.location.href = action?.route;
    }
  };

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="bg-card border border-border rounded-xl p-6 shadow-card">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Zap" size={18} className="text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Quick Actions</h2>
            <p className="text-sm text-muted-foreground">Get started with common tasks</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quickActions?.map((action) => (
            <button
              key={action?.id}
              onClick={() => handleActionClick(action)}
              className="p-4 rounded-lg border border-border bg-card hover:border-primary/30 hover:shadow-soft transition-all duration-200 text-left group"
            >
              <div className="flex items-start space-x-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center border ${getColorClasses(action?.color)}`}>
                  <Icon name={action?.icon} size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                      {action?.title}
                    </h3>
                    {action?.shortcut && (
                      <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                        {action?.shortcut}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{action?.description}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
      {/* Recent Activity */}
      <div className="bg-card border border-border rounded-xl p-6 shadow-card">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
              <Icon name="Activity" size={18} className="text-accent" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-foreground">Recent Activity</h2>
              <p className="text-sm text-muted-foreground">Your latest workspace actions</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
        </div>

        <div className="space-y-4">
          {recentActivities?.map((activity) => (
            <div key={activity?.id} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center border ${getColorClasses(activity?.color)}`}>
                <Icon name={activity?.icon} size={14} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {activity?.title}
                </p>
                <p className="text-xs text-muted-foreground">
                  {formatTimeAgo(activity?.timestamp)}
                </p>
              </div>
              <Button variant="ghost" size="xs" iconName="ExternalLink">
                View
              </Button>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-border">
          <Button variant="ghost" size="sm" iconName="ArrowRight" iconPosition="right" className="w-full">
            View All Activity
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuickActions;