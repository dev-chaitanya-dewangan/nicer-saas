import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import WorkspacePromptInput from './components/WorkspacePromptInput';
import WorkspaceHistory from './components/WorkspaceHistory';
import UsageQuotaCard from './components/UsageQuotaCard';
import TemplateLibrary from './components/TemplateLibrary';
import QuickActions from './components/QuickActions';
import ConversationPanel from './components/ConversationPanel';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const Dashboard = () => {
  const navigate = useNavigate();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [conversationOpen, setConversationOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'LayoutDashboard' },
    { id: 'generate', label: 'Generate', icon: 'Wand2' },
    { id: 'history', label: 'History', icon: 'History' },
    { id: 'templates', label: 'Templates', icon: 'Layout' }
  ];

  const handleGenerate = async (prompt, templateId) => {
    setIsGenerating(true);
    
    // Simulate AI generation process
    try {
      console.log('Generating workspace with prompt:', prompt);
      console.log('Template ID:', templateId);
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Navigate to workspace generator with the prompt
      navigate('/workspace-generator', { 
        state: { 
          prompt, 
          templateId,
          fromDashboard: true 
        } 
      });
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRegenerate = (prompt, theme) => {
    navigate('/workspace-generator', { 
      state: { 
        prompt, 
        theme,
        isRegeneration: true 
      } 
    });
  };

  const handlePreview = (workspaceId) => {
    navigate('/workspace-preview', { 
      state: { 
        workspaceId,
        fromDashboard: true 
      } 
    });
  };

  const handleDeploy = async (workspaceId) => {
    console.log('Deploying workspace:', workspaceId);
    // Simulate deployment process
    await new Promise(resolve => setTimeout(resolve, 2000));
    alert('Workspace deployed successfully to your Notion account!');
  };

  const handleUpgrade = () => {
    navigate('/pricing');
  };

  const handleSelectTemplate = (template) => {
    const prompt = `Create a ${template?.name?.toLowerCase()} workspace with the following features: ${template?.features?.join(', ')}`;
    handleGenerate(prompt, template?.id);
  };

  const handleNavigation = (route) => {
    navigate(route);
  };

  const handleSendMessage = async (message) => {
    console.log('Sending message:', message);
    // Handle conversation message
    return new Promise(resolve => {
      setTimeout(() => {
        resolve('Message sent successfully');
      }, 1000);
    });
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <div className="xl:col-span-2 space-y-6">
              <WorkspacePromptInput 
                onGenerate={handleGenerate}
                isGenerating={isGenerating}
              />
              <QuickActions onNavigate={handleNavigation} />
            </div>
            <div className="space-y-6">
              <UsageQuotaCard onUpgrade={handleUpgrade} />
              <WorkspaceHistory
                onRegenerate={handleRegenerate}
                onPreview={handlePreview}
                onDeploy={handleDeploy}
              />
            </div>
          </div>
        );
      
      case 'generate':
        return (
          <div className="max-w-4xl mx-auto">
            <WorkspacePromptInput 
              onGenerate={handleGenerate}
              isGenerating={isGenerating}
            />
          </div>
        );
      
      case 'history':
        return (
          <div className="max-w-4xl mx-auto">
            <WorkspaceHistory
              onRegenerate={handleRegenerate}
              onPreview={handlePreview}
              onDeploy={handleDeploy}
            />
          </div>
        );
      
      case 'templates':
        return (
          <div className="max-w-6xl mx-auto">
            <TemplateLibrary onSelectTemplate={handleSelectTemplate} />
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar 
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      {/* Main Content */}
      <main className={`
        pt-16 transition-all duration-300 ease-spring min-h-screen
        ${sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'}
      `}>
        <div className="p-6">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
                <p className="text-muted-foreground mt-1">
                  Welcome back! Create and manage your Notion workspaces with AI.
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  size="sm"
                  iconName="MessageSquare"
                  iconPosition="left"
                  onClick={() => setConversationOpen(true)}
                >
                  AI Chat
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  iconName="Plus"
                  iconPosition="left"
                  onClick={() => navigate('/workspace-generator')}
                >
                  New Workspace
                </Button>
              </div>
            </div>

            {/* Tab Navigation */}
            <div className="border-b border-border">
              <nav className="flex space-x-8">
                {tabs?.map((tab) => (
                  <button
                    key={tab?.id}
                    onClick={() => setActiveTab(tab?.id)}
                    className={`
                      flex items-center space-x-2 py-3 px-1 border-b-2 font-medium text-sm transition-colors
                      ${activeTab === tab?.id
                        ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-muted'
                      }
                    `}
                  >
                    <Icon name={tab?.icon} size={16} />
                    <span>{tab?.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          <div className="animate-spring">
            {renderTabContent()}
          </div>

          {/* Loading Overlay */}
          {isGenerating && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-card border border-border rounded-xl p-8 max-w-md mx-4 text-center shadow-floating">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="Wand2" size={32} className="text-primary animate-pulse" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  Generating Your Workspace
                </h3>
                <p className="text-muted-foreground mb-4">
                  Our AI is creating your custom Notion workspace. This may take a few moments...
                </p>
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      {/* Conversation Panel */}
      <ConversationPanel
        isOpen={conversationOpen}
        onClose={() => setConversationOpen(false)}
        onSendMessage={handleSendMessage}
      />
    </div>
  );
};

export default Dashboard;