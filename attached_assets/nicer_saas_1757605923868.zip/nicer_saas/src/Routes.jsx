import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import WorkspaceGenerator from './pages/workspace-generator';
import Dashboard from './pages/dashboard';
import WorkspacePreview from './pages/workspace-preview';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<Dashboard />} />
        <Route path="/workspace-generator" element={<WorkspaceGenerator />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/workspace-preview" element={<WorkspacePreview />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
